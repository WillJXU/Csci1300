#include <iostream>
#include <cmath>
#include <string>

public class ComputerLab{

};

int main(){
    
}