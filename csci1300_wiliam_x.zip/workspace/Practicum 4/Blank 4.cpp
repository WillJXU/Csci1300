#include <iostream>
#include <cmath>
#include <string>


int main(){
    
}