#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <queue>


using namespace std;

// Struct for a linked list node
struct node
{
    int n = 0; // data to be stored in the node
    struct node* next = NULL; // pointer to the next node
};

class HashTable
{
    // No. of buckets (Size of the Hash Table)
    int size;

    // Pointer to an array containing buckets (the Hash Table)
    node **hashTable;

  	/*
  	Method Name: createNode
  	Purpose: Create a node with data as 'key'
    return: pointer to the new node
  	*/
    node* createNode(int key){
	    node* n = new node;
	    n->n = key;
	    return n;
    }

    public:

    /*
    constructor
    Purpose: perform all operations necessary to instantiate a class object
    Param: Size of the Hash Table
    return: none
    */
    HashTable(int s){
	    size = s;
	    hashTable = new node*[s];
    }

  	/*
  	Method Name: insertItem
  	Purpose: inserts a node with data as 'key' into the Hash Table
    return: false if 'key' already exists in the table, otherwise true
  	*/
    bool insertItem(int key){
	    node* n = createNode(key);
	    n->next = hashTable[key%size];
	    hashTable[key%size] = n;
	    std::cout<<"Key "<<key<<" placed in hash "<<key%size<<std::endl;
    }

    /*
  	Method Name: hashFunction
  	Purpose: function to hash "key" into an index
    return: index in the Hash Table
  	*/
    unsigned int hashFunction(int key);

    /*
  	Method Name: printTable
  	Purpose: function to display the Hash Table
    return: none
  	*/
    void printTable(){
	    for (int i = 0;i<size;i++){
		    node* check = hashTable[i];
		    std::cout<<i<<":   ";
		    while(check!= NULL) {
			    std::cout <<check->n<< " ";
			    check = check->next;
		    }
		    std::cout<<std::endl;
	    }
    }

    /*
  	Method Name: searchItem
  	Purpose: function to search for "key" in the Hash Table
    return: node with "key" as it's data if found, otherwise NULL
  	*/
    node* searchItem(int key);
};



int main(int argc, char const *argv[]) {
	HashTable h = HashTable(std::stoi(argv[1]));
	for (int i = 2;i<argc;i++){
		h.insertItem(std::stoi(argv[i]));
	}
	h.printTable();
	return 0;
}
