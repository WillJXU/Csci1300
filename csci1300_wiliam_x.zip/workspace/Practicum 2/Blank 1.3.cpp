#include <iostream>
using namespace std;

#include <cmath>


int main(){
    
}