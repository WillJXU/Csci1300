#include <iostream>
using namespace std;

#include <cmath>
#include <string>

/*Your function should be named removeStars

Your function takes one input argument: string type

Your function returns the string with all the stars (*) removed*/


std::string removeStars(std::string str){
    std::string newstr = str;
    int index = 0;
    for (int i = 0;i<str.length() ;i++){
        if (str[i] !='*'){
            //std::cout <<str[i]<<std::endl;
            newstr[index] = str[i];
            index++;
        }
    }
    return newstr.substr(0,index);
}


int main(){
    std::cout<< removeStars("etwr3**23dbsh*");
}