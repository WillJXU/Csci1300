#include <iostream>
using namespace std;

#include <cmath>
#include <string>
void naturalDiagonal(int num) {
    for (int i=1; i <= num ; i++){ 
        for (int j=1; j <= num; j++){
            if (i != j){
                cout << i;
            }
            else {
                cout << "*";
            }
        }
        cout << endl;
    }
}

int main(){
    naturalDiagonal(4);
}