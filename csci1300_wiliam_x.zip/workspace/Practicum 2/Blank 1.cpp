#include <iostream>
using namespace std;

//std::cout<< <<std::endl;

#include <cmath>

#include <string>
/*Your function should be named CountZeroToFive

Your function should take one string parameter

Your function should return the number of 0, 1, 2, 3, 4, 5 characters as an integer

Your function should not print/output anything*/


char num[6] = {'0','1','2','3','4','5'};
int CountZeroToFive(std::string str){
    int count = 0;
    for (int i = 0; i<str.length();i++){
        for (int j=0;j<6;j++){
            if (str[i] == num[j]){
                count ++;
                break;
            }             
        }
    }
    return count*(count!=0) + -2*(count==0) + -1*(str.length()==0);
}


int main(){
        
}