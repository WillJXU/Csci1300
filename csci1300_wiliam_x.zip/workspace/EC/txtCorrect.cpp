#include <iostream>
#include <cmath>
#include <string>
#include <fstream>

using namespace std;
int split (string str, char c, string array[], int size){
    if (str.length() == 0) {
        return 0;
    }
    string word = "";
    int count = 0;
    str = str + c;
    for (int i = 0; i < str.length(); i++){
        if (str[i] == c){
            if (word.length() == 0)
                continue;
            array[count++] = word;
            //std::cout<<word<<std::endl;
            word = "";
        } else {
            word = word + str[i];
        }
    }
    return count ;
}

class vocab {
    public:
    std::string word[26][600];
    int size[26];
    vocab(){
        for (int c=0;c<26;c++){
            size[c] = 0;
        }
    }
};
  
class misspell {
    public:
    int totword = 0;
    int size = 0;
    std::string msp[7000][2];
    int alpha[26];
};  

class spellCheck {
    public:
    vocab vocabList;
    int vSize;
    misspell mispList;
    int totword = 0;
    std::string in;
    spellCheck(){
    }
    std::string punctChar = "[,./?;’:\"!@#$%^&*()_-+=]";
    string readOnlyChar(string s){
        string str = "";
        for (int i = 0;i<s.length();i++){
            if(((s[i]>=97)&&(s[i]<=122))){
                str = str+s[i];
            }
        }
        return str;
    }
    string readNonChar(string s){
        string str = "";
        for (int i = 0;i<s.length();i++){
            if(!((s[i]>=97)&&(s[i]<=122))){
                str = str+s[i];
            }
        }
        return str;
    }
    int readfile(std::string file){
        std::ifstream f;
        f.open(file);
        if (!f.is_open()){
            std::cout<<file<<" does not exist"<<std::endl;
            return -1;
        }
        if (file.substr(file.length()-3,3)=="txt"){
            while(getline(f,in)){
                if (in == ""){
                    break;
                }
                char c = in[0]-97;
                if (in[0] >= 65 && in[0] <= 90){
                    c = in[0] +32-97;
                }
                vocabList.word[c][vocabList.size[c]] = in;
                vocabList.size[c]++;
                vSize++;
            }
            std::cout<<"Read "<<vSize<<" words from "<<file<<std::endl;
            return vSize;
        }
        while(getline(f,in)){
            if (in == ""){
                break;
            }
            char c = in[0]-97;
            if (in[0] >= 65 && in[0] <= 90){
                c = in[0] +32-97;
            }
            std::string err[100];
            int misp = split(in.substr(in.find(",")+1,in.length()-in.find(",")),'|',err,10);
            for(int i = 0;i<misp;i++){
                mispList.msp[mispList.totword][1] = in.substr(0,in.find(","));
                mispList.msp[mispList.totword][2] = err[i];
                //std::cout<<mispList.msp[mispList.totword][1]<<std::endl;
                //std::cout<<"    "<<mispList.msp[mispList.totword][2]<<std::endl;
                mispList.totword++;
            }
            mispList.size++;
        }
        std::cout<<"Read "<<mispList.size<<" words from "<<file<<std::endl;
        return totword;
    }    
    std::string punct(std::string s){
        std::string arr[100];
        int size = split(s, ' ', arr,100);
        for (int i = 0;i<size;i++){
            if(!(((arr[i][0]>=97)&&(arr[i][0]<=122))||((arr[i][0]>=48)&&(arr[i][0]<=57)))){
                bool punctbreak = false;
                int eraseUpto = 0;
                for (int j = 0;j<arr[i].length();j++){
                    if(!((arr[i][j]>=97)&&(arr[i][j]<=122))){
                        eraseUpto++;
                    }
                    else{
                        punctbreak = true;
                        break;
                    }
                    if (punctbreak){
                        break;
                    }
                }
                //cout<<eraseUpto<<endl;
                arr[i] = arr[i].substr(eraseUpto,arr[i].length()- eraseUpto);
            }
            //cout<<arr[i]<<endl;
        }
        std::string str = "";
        for (int i = 0;i<size;i++){
            if (arr[i] != ""){
                str = str + arr[i] + " ";
            }
        }
        return str;        
    }
    std::string cap(std::string s){
        for(int i = 0; i<s.length();i++){
            if(((s[i]>=65)&&(s[i]<=90))||((s[i]>=97)&&(s[i]<=122))){
                bool lc = (s[i]>=97&&s[i]<=122);
                s[i] = ((s[i])*lc)+((s[i]+32)*!lc);
                //std::cout<<s[i]<<std::endl;
            }  
        }
        return s;
    }
    std::string autoCorrect(std::string s){
        std::string arr[100];
        int size = split(s, ' ', arr,100);
        for (int i = 0;i<size;i++){
            int c = arr[i][0]-97;
            if(((arr[i][0]>=65)&&(arr[i][0]<=90))||((arr[i][0]>=97)&&(arr[i][0]<=122))){
                bool lc = (arr[i][0]>=97&&arr[i][0]<=122);
                c = ((arr[i][0] - 97)*lc)+((arr[i][0] - 65)*!lc);
            }
            else{
                continue;
            }
            bool found = false;
            string k = readOnlyChar(arr[i]);
            //cout<<k<<endl;
            for (int v = 0; v<vocabList.size[c];v++){
                if(k == vocabList.word[c][v]){
                    found = true;
                    break;
                }
            }
            if (found){
                continue;
            }
            bool unknown = true;
            for (int m = 0;m<mispList.totword;m++){
                if(k == mispList.msp[m][2]){
                    k = mispList.msp[m][1];
                    arr[i] = k+readNonChar(arr[i]);
                    unknown = false;
                    break;
                }
            }
            if (unknown){
                string s = "unknown";
                for (int d = 0;d<arr[i].length();d++){
                    if(!((arr[i][d]>=97)&&(arr[i][d]<=122))){
                        s = s+arr[i][d];
                    }
                }
                arr[i] = s;
            }
        }
        std::string str = "";
        for (int i = 0;i<size;i++){
            str = str + arr[i] + " ";
        }
        return str;
    }
    
    std::string space(std::string s){
        std::string str;
        int c = 0;
        bool space = false;
        int start;
        std::string arr[100];
        int size = split(s, ' ', arr,100);
        for (int i = 0;i<size;i++){
                str = str + arr[i] + " ";
        }
        return str;
    }        
};

int main(){
    //misspell m;
    spellCheck sC;
    sC.readfile("vocabulary.txt");
    sC.readfile("misspelling.csv");
    std::string in;
    std::cout<<"Enter the phrase you would like to correct:"<<std::endl;
    getline(cin,in);
    in = sC.cap(in);
    //cout<<in<<endl;
    in = sC.punct(in);
   // cout<<in<<endl;
    in = sC.autoCorrect(in);
    //cout<<in<<endl;
    in = sC.space(in);
    std::cout<<in<<std::endl;
}