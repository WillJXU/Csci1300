#include <iostream>
#include <math.h>
using namespace std;

void sphereVolume(float r){
    std::cout << "volume: " << (4.0/3.0)*M_PI*pow(r, 3)<< std::endl;
}


int main(){

    cout << "Enter a radius: " << endl;
    float radius;
    cin >> radius;
    sphereVolume(radius);
    float volume;
    float sa;
    volume = (4.0/3.0) * M_PI * pow(radius, 3);
    sa = 4*M_PI*pow(radius,2);
    cout << "volume: " << volume << endl;
    cout << "surface area: " << sa << endl;
    
    //your code goes here
   
}
