#include <iostream>
#include <string>

int getWordCount(std::string txt){
    int word = 0;
    for (int i = 1; i<=txt.length();i++){
        if (txt[i] == ' '){
            word++;
        }
    }
    return word+(1*txt.length());
}

#include <cstdlib> 

int getDigitCount(std::string txt){
    int digit = 0;
    for(int i = 0; i<=txt.length();i++){
        int currchar = (int)txt[i]-48;
        //std::cout << currchar <<std::endl;
        if (currchar< 10 && currchar >=0){
            digit++;
        }
    }
    return digit;
}


std::string sub;
std::string str;
int looped = 0;
int charloop(int pos,int index){
    //std::cout << pos<<","<<index<<std::endl;
    if (index <= sub.length()-1){
        //std::cout <<str[pos]<<","<<sub[index]<<std::endl;
        if (str[pos] == sub[index]){
            if (index == (sub.length()-1)){
                std::cout <<"Successful loop"<<std::endl;
                looped++;
                return 1;
            }
            charloop(++pos,++index);
        }
        else{
            return 0;
        }
    }
    return 0;
}
int getMatchCount(std::string x,std::string y){
    sub = x;
    str = y;
    if ( (str.length()<sub.length() ) || ( (str.length()*sub.length())==0 ) ){
        return -1-((str.length()*sub.length())!=0);
    }
    for(int i = 0; i <=str.length();i++){
        if (str[i] == sub[0]){
            charloop(i,0);
        }
    }    
    return looped;
}

int getLastIndex(char let,std::string txt){
    if (txt.length()==0){
        return -1;
    }
    int lastindex = -2;
    for(int i = 0; i <=txt.length();i++){
        if (txt[i] == let){
            lastindex = i;
        }
    }
    return lastindex;
}


int main(){
    std::cout<<getLastIndex('z',"zebra")<<std::endl;

}
