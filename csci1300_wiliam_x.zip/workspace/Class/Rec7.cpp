#include <iostream>
#include <fstream>

void replaceNums(int tab[], int length){
    int memory[length];
    memory[0] = tab[0];
    memory[length-1] = tab[length-1];
    for (int i = 1; i<length-1;i++){
        int comp = ((tab[i-1]*(tab[i-1]>=tab[i+1]))+(tab[i+1]*(tab[i-1]<tab[i+1])));
        memory[i] = (tab[i]*(tab[i]>=comp)+comp*(tab[i]<comp));
    }
    for (int i = 0; i<length;i++){
        tab[i] = memory[i];
       // std::cout<<tab[i]<<" ";
    }
}

void printTwoDArray(int array[][5], int length){
    if (length <= 0){
        std::cout<< -1*(length<0);
    }
    for(int i = 0;i<length;i++){
        for(int j = 0;j<5;j++){
            std::cout << array[i][j];
            if (j!= 4){
                std::cout<<",";
            }
        }
        std::cout<<std::endl;
    }
}


void floodMap(double map[][4],int row,double wl){
    for(int i = 0;i<row;i++){
        for(int j = 0;j<4;j++){
            char state = '*'*(map[i][j]>wl)+'_'*(map[i][j]<wl);
            std::cout<<state;
        }
        std::cout<<std::endl;
    }
}
int getLinesFromFile(std::string fn, int arr[], int len){
    ifstream file;
    file.open(fn);
    if (!file.is_open()){
        return -1;
    }
    std::string line = "";
    int lineidx = 0;
    while (getline(file, line)&&(lineidx<len)){
        if(line!=""){
            arr[lineidx] = stoi(line);
            lineidx++;
        }
    }
    return lineidx;
}


int main(){
    int tab[9];
    getLinesFromFile("fstreamtest",tab,9);
}