#include <iostream>
#include <string>
using namespace std;
// above ^ are the preprocessor directives


int main()
{
    //Let's declare an integer
    int x = 5;

    /*What's different than Python/Matlab? You HAVE to specify the type of the variable at declaration
    The line also ends in a semicolon. Forgetting the ; will generate an error !!! 
    Check out the Common Errors document
    */

    //Declaration vs Initialization
    int inta = 7;       // Declaration and initialization in the same statement
    int intb,intd; // Just variable declarations
    intb = 3;		// Variable intb is initialized to the value 3
    int intc = intd;   //Not a good idea. intd has not been initialized yet. Might get garbage
    cout << "intc = " << intc << ", intd = " << intd << endl << endl;
    
    // Reassignment
    intb = inta + intb;  // intb is reassigned a new value

    //floating point numbers, aka real numbers
    double dbla;
    dbla = 3.5;

    /*there is also a float data type that is floating point, but uses less
    memory than double. In data structures, discrete structures, and numerical
    analysis you will learn more about the nuances of floating point arithmetic
    and how unexpected things can happen.*/
    float fltA = 3.866;
    
    // identifier rules: names must start with a letter or _. Cannot use reserved words
    // Can we do this?
    // float 1st_flt = 0.5
    // float switch = -2.5

    // Characters and strings. Must add a library to handle strings
    char ch1 = 'A';
    char ch2 = '0';
    char ch3 = '#';
    char ch4 = ' ';
    //char ch5 = ''; // can we declare an empty character?
    
    string str1 = "io";
    string str2 = "100";
    string str3 = "";  // can we declare an empty string?

    // Variables cannot be declared before they are used
    inta = intb + int7; // have we decalred and initialized intb before? How about int7?
    
    // outputing/printing something to the console (terminal window): use cout
    cout << "Hello world!\n";   // output just text (a string message)
    cout << " " << fltA << endl;  // cascade by using << repeatdly. Here we have text, the value of fltA and thr new line
    // endl above ^is the equivalent of '\n' (new line) in Python/Matlab

    //Operations on variables, such as *,+,-,/
    //Let's do some operations with integers and output the result
    inta = 5;
    intb = 7;
    intc = inta + intb / inta;
    intd = inta % intb;

    cout << "inta = " << inta << endl;
    cout << "intb = " << intb << endl;
    cout << "intc = " << intc << endl;
    cout << "intd = " << intd << endl;
    
    return 0;
}
