/*
 * C++ is a useful language to learn because it forces you to pay
 * attention to variable types and memory and some of the stuff going
 * on behind the scenes that other languages (like Python, Matlab) hide.
 * The functionality for the language is included with libraries and
 * namespaces. To use the functionality associated with the iostream,
 * we need to include the iostream library. These files are also
 * called header files, or .h files.
 *
*/
/* All of the standard C++ functionality is included in a namespace
 * called std. To use this functionality, we need to let the program
 * know that we want it included, so you say "using namespace std".
 * There are other namespaces, but we're not going to get into that.
*/

#include <iostream>
using namespace std;
// above ^ are the preprocessor directives

int main()  // the main function. In between the curly braces is the function definition
{
    cout << "Hello World" << endl;  // statement that outputs a message to the console
    return 0;  // last line in the function definition
}
