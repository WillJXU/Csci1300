#include <iostream>
#include<string>
#include <fstream>
bool checkFile(std::string filename){
    std::ifstream i;
    i.open(filename);
    return i.is_open();
}

int fileLoadWrite(std::string filename){
    std::ofstream f;
    f.open(filename);
    if (!f.is_open()){
        return -1;
    }
    for (int i=1;i<=10;i++){
        f <<i*i << std::endl;
    }
    return 0;
}
int fileLoadRead(std::string filename){
    std::ifstream f;
    f.open(filename);
    if (!f.is_open()){
        return -1;
    }
    std::string a;
    int b = 0;
    while (getline(f, a)){
        b++;
    }
    return b;
}


void saveData(std::string filename, std::string arr[], int n, int size){
    std::ofstream f;
    f.open(filename);
    if (!f.is_open()){
        std::cout <<"file open failed"<<std::endl;
        return;
    }
    if (arr[size-1] != ""){
        f << "Name: " << arr[size-1]<<std::endl;
    }
    double sum = 0;
    for (int i = 0; i<n;i++){
        sum+=std::stod(arr[i]);
    }
    if (n>0){
        f << "Avg: " << sum/n<<std::endl;
    }
}
int main(){
    std::cout<<fileLoadWrite("Text.txt");
}