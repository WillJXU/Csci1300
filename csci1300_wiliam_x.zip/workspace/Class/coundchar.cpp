#include <iostream>
#include <fstream>

int isPrime(int arr[],int size){
    int notPrimes = 0;
    for (int i = 0; i < size; i ++){
        bool a = false;
        if (arr[i] == 0 || arr[i]==1){
            notPrimes++;
            a = true;
        }
        if (arr[i] == 2){
            notPrimes--;
            a = true;
        }
        if (a == false){
            for (int j=2; j < arr[i]; j++){
                if(arr[i]%j != 0){
                    notPrimes++;
                    break;
                }
            }
        }
    }
    return size - notPrimes;
}


int main(){
    int a[5] = {0,1,2,3,4};
    std::cout<<isPrime(a,5);
}