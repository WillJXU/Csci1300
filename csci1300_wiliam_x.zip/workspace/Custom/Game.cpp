#include <iostream>
#include <string>

int pcount;
int mapsize;
int game = 0;
std::string currplr ;
int turn = 0;
int map = {};


std::string news = "news";
std::string playerIcon = "!@#$%^&*-=";

void actionread(int action){
    switch(action){
        case 0:break;
        case 1:;/*Pass*/
        case 2:;/*Examine*/
        case 3:;/*Hit*/
        case 4:;/*Mine*/
    }
}

void moveread(char move){
    for (int a = 0; a <= 5; a++){
        if (move == news[a]) {
            std::cout << "What action?" << std::endl;
            int action;
            std::cout << "Input number next to action"<<std::endl;
            std::cout << "0. Pass"<<std::endl;
            std::cout << "1. Examine"<<std::endl;
            std::cout << "2. Hit"<<std::endl;
            std::cout << "3. Move"<<std::endl;
            std::cout << "4. Place mine"<<std::endl;
            std::cin >> action ;
        }
        else {
            std::cout << "Invalid input, please select valid input"<<std::endl;
            char move;
            std::cout << "Move which direction, "<< currplr <<"? (n,e,w,s)"<<std::endl;
            std::cin >> move;
            moveread(move);  
        }
    }
    
}


int main(){
    std::cout << "How many players?"<<std::endl;
    std::cin >> pcount;
    std::cout << "What map size?"<<std::endl;
    std::cin >> mapsize;
    map = map[mapsize][mapsize];
    while (game == 0){ ;
        turn++;
        currplr = "Player" + std::to_string(turn%pcount) + playerIcon[turn%pcount];
        std::cout << currplr <<std::endl;
        char move;
        std::cout << "Move which direction, "<< currplr <<"? (n,e,w,s)"<<std::endl;
        std::cin >> move;
        moveread(move);
    }
}