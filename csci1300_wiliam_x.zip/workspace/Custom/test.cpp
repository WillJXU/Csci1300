#include <iostream>
#include <math.h>
using namespace std;
//cd myCppProjects
//cd cppProjects
int main()
    
    
{   
    
    float a, b, sumOfNumbers, diffOfNumbers, prodOfNumbers, divOfNumbers, powOfNumbers;
        
    cout << "Enter two numbers: " << endl;
    cin >> a;
    cin >> b;
    
    //Create a calculator for the numbers
    sumOfNumbers = a + b;
    diffOfNumbers = b - a;
    prodOfNumbers = a * b;
    divOfNumbers = a / b;
    powOfNumbers = pow(a,b);
    //Print the statements
    cout << "The sum of the numbers is: " << sumOfNumbers << endl;
    cout << "The difference of the numbers is: " << diffOfNumbers << endl;
    cout << "The product of the numbers is: " << prodOfNumbers << endl;
    cout << "The quotient of the numbers is: " << divOfNumbers << endl;
    cout << "The power of the numbers is: " << powOfNumbers << endl;
    
    
    return 0;
    
}