// my first pointer
#include <iostream>
using namespace std;
int a = 15/4;
int b = 4;
float x = 15/4;
float y = 3.0 / 4.0 + (3 + 2 )/ 5;

int main (){
    //std::cout << &a<<","<<&b<<std::endl;
    std::cout << x<<std::endl;
    std::cout << y<<std::endl;
    std::cout << ( 3 < 2 && 10 < -2)<<std::endl;
}