#include <iostream>

int table[3][3];
int inntertab[3] = {1,2,3} ;

int main(){
    table[1] = inntertab;
}