#include <iostream>   // std::cout
#include <string> 
using namespace std;
std::string decimalToBinaryRecursive(int i){
    if (i == 0)
        return "0";
    return decimalToBinaryRecursive((i-(i%2))/2)+to_string(i%2);
}
int main(){
    for (int i = 0;i<100;i++){
        std::cout<<decimalToBinaryRecursive(i)<<std::endl;
    }
}