#include <iostream>
using namespace std;
string name;
string dialog;
int N;
int Max;
int Min;
int main(){

std::cout << "What is your name?" << std::endl;
std::cin >> name;
std::cout << "Hello, " << name<<"!"<< std::endl;
std::cout << "Would you like to play a game?" << std::endl;
std::cin >> dialog;
std::cout << "Well you don't have a choice here." << std::endl;
}