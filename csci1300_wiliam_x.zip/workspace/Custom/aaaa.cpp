#include <string>
#include <iostream>
#include <fstream>
using namespace std;
int split (string str, char c, string array[], int size);
struct UniqueWord{    
    string word;    
    int noOccurances = 0;  
};
int main(){
    int size = 59; //Number of words in the read in file
    string arr[size]; //String of 59 words
    ifstream f; //Reading in the text file
    string s;
    f.open("cleanedText.txt"); //
    cout << "Word" << endl;
    getline(f,s);
    int w = 0; //Number of unique words 
    int j = split(s, ' ', arr, 59); //Each word in the file
    UniqueWord uw[j];
    for (int i=0; i<j;i++){//Cycling through the number of words in the array
        bool isWordUnique = true;
        int index;
        for (int l=0;l<w;l++){ //Cycling through the number of unique words in the array
            if (uw[l].word == arr[i]){
                isWordUnique = false;
                index = l; 
            }
        } 
        if(isWordUnique == true){
            uw[w].word = arr[i];
            uw[w].noOccurances++;
            w++;
        }
        else{
            uw[index].noOccurances++;
        }
    }
    for (int m=0; m<w; m++){
        cout << uw[m].word << " COW " << uw[m].noOccurances << endl; 
    }
    return 0;
}
int split (string str, char c, string array[], int size)
{
    if (str.length() == 0) {
        return 0;
    }
    string word = "";
    int count = 0;
    str = str + c;
    for (int i = 0; i < str.length(); i++){
        if (str[i] == c){
            if (word.length() == 0)
                continue;
            array[count++] = word;
            word = "";
        } else {
            word = word + str[i];
        }
    }
    return count ;
}