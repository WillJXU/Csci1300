#include <iostream>
#include <string> 
#include <stdlib.h> 

int split(std::string txt, char seper, std::string array[], int maxchar){
    int lastcharindex = 0;
    int tableindex = 0;
    int wordcount=0;
    for (int i = 0;i<txt.length();i++){
        int isLastText = (i == (txt.length()-1))&&(txt[i]==txt[(txt.length()-1)]);
        if ((txt[i] == seper)||(isLastText)){
            std::string str = txt.substr(lastcharindex,i-lastcharindex+(isLastText));
            str = str.substr(0,str.find(seper));
            if (str.length() != 0){
                array[tableindex] = str;
                tableindex++;
            }
            lastcharindex = i+1;
            if ((str.length()<= maxchar)&&(str.length()!=0)){
                wordcount++;
            }
        }
    }
    return wordcount;
}


int getScores(std::string list, int table[], int maxelem){
    std::string temptable[maxelem];
    int a = split(list,',',temptable,10);
    for (int i = 0;i<a;i++){
        table[i] = std::stoi(temptable[i]);
    }
    return a*(a<maxelem)+maxelem*(a>maxelem);
}

#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <chrono>
#include <thread>
#include <vector>
#include <numeric>

 
volatile int sink;
int main()
{
    for (auto size = 1ull; size < 1000000000ull; size *= 100) {
        // record start time
        auto start = std::chrono::system_clock::now();
        // do some work
        std::vector<int> v(size, 42);
        sink = std::accumulate(v.begin(), v.end(), 0u); // make sure it's a side effect
        // record end time
        auto end = std::chrono::system_clock::now();
        std::chrono::duration<double> diff = end-start;
        std::cout << "Time to fill and iterate a vector of " 
                  << size << " ints : " << diff.count() << " s\n";
    }
}