#include <iostream>
using namespace std;
int a;
char b;

string fug(){
    switch(rand()%6+1){
    case 1: return "AAAAAHHHH";
    case 2: return "MAKE IT END";
    case 3: return "STOP";
    case 4: return "KILL ME";
    case 5: return "Do you think god stays in heaven because he too fears what he created?";
    case 6: return "I WANT TO DIE";
    }
}


void sheeeeeiiiittt(){
    int d = 0;
    do{
    d = ++d;
    std::cout << d << " " << fug() <<std::endl;
    }
    while (d < a);
}



int main() {
    std::cout << "Enter a CS course number" <<std::endl;
    std::cin >> a; 

    std::cout << "Hello, CS " << a <<" World!"<<std::endl;
   sheeeeeiiiittt();
}

