#include <iostream>

struct Item {
    std::string Name = "Nil";
    int Quantity = 0;
};

int main(){
    Item Banana; 
    Banana.Name = "Banana";
    Banana.Quantity=3;
    Item *b;
    b = &Banana.Name;
    std::cout<< *b;
}
