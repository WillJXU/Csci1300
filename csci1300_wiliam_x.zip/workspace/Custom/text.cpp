#include <iostream>

void printMultiples(int incre,int max){
    for(int i = 1;i<=(max/incre);i++){
        std::cout << i*incre <<std::endl;
    }
}    

#include <string>
void printSquares(int width){
    std::string sign[2] = {"*"," "};
    int x;
    int y;
    for(int i = 1;i<=(width*width*2+width);i++){
        y = ( (i/ ( (width*2) +1) ) +1);
        x = ( ( (i-1) % ( (width*2) +1) +1) );
        //std::cout<<"["<<x<<","<<y<<"]";
        //std::cout<<"["<<((x>=(width+3))&&(x<(width*2+1)))<<((y>=2)&&(y<width))<<"]";
        std::cout << sign[((x>=(width+3))&&(x<(width*2+1))) && ((y>=2)&&(y<width))||(x%(width*2+1)==width+1)];
        if ((i%(width*2+1)) == 0){
            std::cout<<std::endl;
//            std::cout<<std::endl;

        }
    }
}

#include <cmath>
void printDiamond(int sl){
    std::string sign[2] = {"*"," "};
    int x,y;
    for(int i = 1;i<=(pow(2*sl-1,2));i++){
        std::cout<<sign[!(((sl-abs(sl-(((i-1)%(sl*2-1)+1))))+(sl-abs(sl-(((i-1)/(sl*2-1))+1))))>=(sl+1))];
        if ((i%(sl*2-1)) == 0){
            std::cout<<std::endl;
        }   
    }
}
        //x = (((i-1)%(sl*2-1)+1));
        //y = (((i-1)/(sl*2-1))+1);
        //std::cout<<"["<<x<<y<<"]";
        //std::cout<< (((sl-abs(sl-x))+(sl-abs(sl-y)))>=(sl+1));



int main(){
    printDiamond(12);
    printSquares(4);
}