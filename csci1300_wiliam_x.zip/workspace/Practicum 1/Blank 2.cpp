#include <iostream>
#include <cmath>

#include<string>

std::string shape[6] = {"UNKNOWN","CONE","CYLINDER","TRIANGULARPYRAMID","UNKNOWN","CUBOID"};

std::string shapeName(int surf){
    if ((surf<0) || (surf > 6)){
        return "UNKNOWN";
    }
    return shape[surf-1];
}

int main(){
    std::cout<<shapeName(2)<<std::endl;    
}