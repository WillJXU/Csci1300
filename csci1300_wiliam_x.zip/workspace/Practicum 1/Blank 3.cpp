#include <iostream>
#include <cmath>
#include<string>
std::string opt[4] = {"Play Game","View Stats","Save Game","Exit Game"};

void gameMenu(int x){
    switch (x){
        case 1:
        case 2:
        case 3:
        case 4:
            std::cout <<"Choice "<< x<<": "<<opt[x-1]<<std::endl;
            return;
        break;
    }
    std::cout <<"Choice "<< x<<": "<<"Invalid"<<std::endl;            
    
}

int main(){
    gameMenu(3);
    gameMenu(14);
}