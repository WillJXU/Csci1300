#include <iostream>
#include <cmath>

int main(){
    
}