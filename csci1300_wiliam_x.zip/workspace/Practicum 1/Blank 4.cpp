#include <iostream>
#include <cmath>

double largestNumber(double x,double y,double z){
    if ((x>=y)&&(x>=z)){
        return x;
    }
    if ((y>=x)&&(y>=z)){
        return y;
    }
    if ((z>=x)&&(z>=y)){
        return z;
    }
}


int main(){
    std::cout<<largestNumber(10,12.5,62.5)<<std::endl;
}