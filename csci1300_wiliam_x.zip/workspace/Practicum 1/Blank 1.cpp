#include <iostream>
#include <cmath>

double hikingTime(double dist, double ele){
    double time;
    time = (1/3.0)*dist + (1/2000.0)*(ele);
    if (time < 0){
        time = dist/5;
    }
    return time;  
}

int main(){
    std::cout <<hikingTime(5.0,-4000.0)<<std::endl;
}