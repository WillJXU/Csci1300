#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
struct wordItem{
	std::string word;
	int count = 0;
};


void getStopWords(const char *igWFN, std::string ignWo[]){
	std::ifstream f;
	f.open(igWFN);
	if (!f.is_open()){
		std::cout << "Failed to open " << igWFN <<std::endl;
		return;
	}
	std::string s;
	int i = 0;
	while (getline(f,s)){
		ignWo[i] = s;
		i++;
	}
}

bool isStopWord(std::string word, std::string igW[]){
	for (int i = 0;i<50; i++){
		if (word == igW[i]){
			return true;
		}
	}
	return false;
}

int getTotalNumberNonStopWords(wordItem uqW[], int len){
  int c = 0;
	for (int i = 0;i<len; i++){
        c = c+uqW[i].count;
	}
	return c;
}
int insertIntoSortedArray(wordItem myArray[], int len, wordItem val){
    int point=len;
    for (int i = 0;i<len;i++){
        if (myArray[i].count>=val.count){
            point = i;
            break;
        }
    }
    wordItem* nel;
		nel = new wordItem[len+1];
	  for (int i = point; i<len;i++){
        *(nel+i+1) = myArray[i];
				std::cout<<"["<<i<<", "<<point<<"]"<<"Array: "<<myArray[i].word<<" nel: "<<nel[i].word<<std::endl;
    }
		for (int i = point; i<len+1;i++){
				//myArray[i] = nel[i];
		}
		//std::cout<<myArray[point].word<<":"<<val.word<<std::endl;
    myArray[point] = val;
		std::cout<<"After reassignment: "<<myArray[point].word<<":"<<val.word<<std::endl;
		delete [] nel;
    return point;
}
void test(wordItem myArray[], wordItem val, int i){
	std::cout<<myArray[i].word<<" "<<val.word<<std::endl;
}

int const Arrsize = 200;
void arraySort(wordItem uW[], int len){
	int size = 0;
	wordItem word[len];
	//word = new wordItem [len];
	for (int i = 0;i<len;i++){
		//std::cout<<uW[i].word<<std::endl;
		insertIntoSortedArray(word,size,uW[i]);
		//test(uW,uW[i],i);
		//int point = insertIntoSortedArray(word,size,uW[i]);
		//std::cout<<"[UNQ ARRAY]"<<uW[i].word<<" count: "<<uW[i].count<<" at "<<i<<". Size "<<size+1<<std::endl;
		//std::cout<<"[WORD ARRAY]"<<word[i].word<<" count: "<<word[i].count<<" at "<<point<<". Size "<<size+1<<std::endl;
		size = size+1;
		std::cout<<size<<std::endl;
	}
	//delete [] uW;
	//uW = word;
}

void printTopN(wordItem uniqueWords[], int topN, int totalNumWords){
    std::cout << std::fixed;
	for (int i = 0; i<topN;i++){
	    //std::cout<< uniqueWords[i].count<<std::endl;
		std::cout<< std::setprecision(4)<<((float) uniqueWords[i].count / totalNumWords)<<" - "<<uniqueWords[i].word<<std::endl;
	}
}
int const incresize = 100;

int main(int argc, char* argv[]) {
	if (argc != 4){
		std::cout << "Usage: Assignment2Solution" << argv[1] << argv[2] << argv[3] <<std::endl;
		return 0;
	}
	int dub = 0;
	std::string s = argv[2];
	std::ifstream f;
	f.open(s);
	getline(f,s);
	int letter = 0;
	int lastSpace = 0;
	wordItem *unq = new wordItem [incresize];
	int count = 0;
	int lim = incresize;
	std::string stop[50];
	getStopWords(argv[3],stop);
	while(letter <= s.length()){
		if (s[letter] == ' '){
			std::string word;
			word = s.substr(lastSpace+(count != 0),(letter-lastSpace)-1);
			//std::cout<<count<<word<<std::endl;
			if (!isStopWord(word,stop)){
				bool found = false;
				for (int i = 0;i<count;i++){
					if (word == unq[i].word){
						unq[i].count = unq[i].count+1;
						found = true;
						//std::cout<<unq[i].word<<":"<<unq[i].count<<std::endl;
						break;
					}
				}
				if (!found){
					if (count+1 >= lim){
						wordItem *temp;
						temp = new wordItem [lim*2];
						for (int i=0;i<count;i++){
							temp[i] = unq[i];
							temp[i].count = unq[i].count;
						}
						delete [] unq;
						unq = temp;
						lim = 2*lim;
						dub++;
					}
					wordItem w;
					w.word = word;
					w.count = 1;
					unq[count+1] = w;
					count = count+1;
				}
			}
			lastSpace = letter;
		}
		letter++;
	}

	int tot = getTotalNumberNonStopWords(unq,count);
	std::cout<<tot<<","<<count<<std::endl;
  arraySort(unq,count);
	std::cout<<"Array doubled: "<<dub<<std::endl;
	std::cout<<"#"<<std::endl;
	std::cout<<"Unique non-common words: "<< count <<std::endl;
	std::cout<<"#"<<std::endl;
	std::cout<<"Total non-common words: "<< tot<<std::endl;
	std::cout<<"#"<<std::endl;
	std::cout<<"Probabilities of top 10 most frequent words"<<std::endl;
	std::cout<<"---------------------------------------"<<std::endl;
	printTopN(unq,std::stoi(argv[1]),tot);
	return 0;
}
