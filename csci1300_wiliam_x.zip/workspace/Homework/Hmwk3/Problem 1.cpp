//William Xue: CSI1300 Fall 2017
//Rec: 206 Lucas Hayne
// Homework 3 - Problem 1

#include <iostream>

/*
    Algorithm: 
    1.input(i, an integer number)
    2.If i is divisible by 2 then divide it by 2 and return the value
    3.Else multiply it by three and add one and return the value
*/


int realfunction(int n){
    //Return 0 if n is negative 
    if (n < 0){
        return 0;
    }
    //Check if even, if so divide by 2
    else if (n%2 == 0){
        return n/2;
    }
    //Other wise do the other thing
    else{
        return n*3+1;
    }
}

int collatzStep(int n){
    return (((3*n+1)*(n%2))+((n/2)*((n%2)==0)))*(n>=0);
}

int main(){
    for (int i = -10;i<20;i++){
        std::cout <<i<< "  "<< collatzStep(i)<< std::endl;    
        std::cout <<i<< "  "<< realfunction(i)<< std::endl;    
    }
    
}

