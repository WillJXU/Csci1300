//William Xue: CSI1300 Fall 2017
//Rec: 206 Lucas Hayne
// Homework 3 - Problem 2
#include<iostream>

/*
Algorithm: 
    1.input(i, an integer number)
    2.power = the number that repersents the power of 10, starts from 0
    3.if "i" is less than 0 then multiply "i" by -1
    4.loop code: 
        4a. if "i" divided by 10 to the power of "power" is less than or equal to
        1 then add "power" by 1 and restart the loop.
        4b. else return "power"

*/

int realfunction(int n){
    int digit = 0;
    // Fix if n is negative
    if (n < 0){
        n = -n;
    }
    //check if n is larger than the nested comparison and change the 
    //value "digit"
    if (n >= 1){
        digit = 1;
        if (n >= 10){
            digit = 2;
            if (n >= 100){
                digit = 3;
                if (n >= 1000){
                    digit = 4;
                }
            }
        }   
    } 
    //return the value
    return digit;
}

#include <math.h>  
int countDigits(int n){
    // Set up n to be positive
    n = n*(n>0)-n*(n<0);
    // Set up digit placement value, d.
    int d = 0;
    // Do while loop that increments until the n value divided by the 10 to the 
    // power of d is less than or equal to  1
    do{
        d++;
    } while ((n/pow(10,d)>=1));
    return d;
}

int main(){
    int numtable[20] = {0,1,2,3,4,5,6,7,8,9,0,0,0,0,0,0,0,0,0,0};
    for (int i=-100;i<20;i++){
        int r = 0;
        int maxdig = 4;
        int digit = rand()%maxdig;
        int posneg = (pow(-1, rand()%2));
        for (int l = 0 ; l < digit; l++){
            r = r + (numtable[rand()%20])*pow(10,l); 
        }
        r = r*posneg;
        std::cout <<r<<", "<< realfunction(r)<<std::endl;
        std::cout <<r<<", "<< countDigits(r)<<std::endl;
    }
}