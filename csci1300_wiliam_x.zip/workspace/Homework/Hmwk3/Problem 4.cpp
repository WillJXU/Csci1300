#include <iostream>

void vehicle(bool dl, bool dr, bool cl, bool ml, bool ill, bool oll, bool irl, bool orl, char gs){
    int ld = 0;
    int rd = 0;
    if (ml or (gs!= 'P')){
    std::cout <<"Both doors stay closed"<<std::endl;
    return;
    }
    if (~cl&&((~dl && oll) || (~dl && ill))){
        ld = 1;

    return;
    }
    if (~cl&&((~dr&& orl) || (~dr && irl))){
        rd = 1;
    return;

    }
    if (ld && rd){
        std::cout <<"Both doors open"<<std::endl;
    return;
    }
    else if(ld){
        std::cout <<"Left door opens"<<std::endl;        
    }
    else{
        std::cout <<"Right door opens"<<std::endl;
    }
}


int main(){
    vehicle(0, 0, 0, 0, 0, 0, 1, 0, 'P');
    vehicle(0, 0, 1, 0, 1, 1, 0, 0, 'R');
}
