//William Xue: CSI1300 Fall 2017
//Rec: 206 Lucas Hayne
// Homework 3 - Problem 1
#include <iostream>
/*
    Algorithm: 
    1. input(month, an integer value)
    2. check if the number is a valid number by seeing if the number falls 
    between the [0,12] number range.
        2a. if the number is invalid set i to 0
    3. Check the value with i for the available cases
        3a. In a case i is 0 output("Invalid month number")
        3b. In a case i is 1,3,5,7,8,10, or 12 output("Month"..i.."has" 31 days")
        3c. In a case i is 4,6,9, or 11 output("Month"..i.."has 30 days")
        3d. In a case i is 2 output("Month 2 has 28 or 29 days")
*/


void realfunction(int day){
    // Check if valid month
    if (((day < 0) or (day > 12))){
        day = 0;
    }
    switch (day){
        //if case 0 output invalid number
        case 0:
            std::cout<<"Invalid month number"<<std::endl;
        break;
        //if any of the number below out put that it has 31 days
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            std::cout << "Month "<<day<<" has 31 days" << std::endl;    
        break;
        //if any of the number below out put that it has 30 days
        case 4:
        case 6:
        case 9:
        case 11:
            std::cout << "Month "<<day<<" has 30 days" << std::endl;
        break;
        // In a spacial case with day == 2, output this month has either 28 or 29 days
        case 2:
            std::cout<<"Month 2 has 28 or 29 days"<<std::endl;
        break;
    }
}

#include <string>
void daysOfMonth(int d){
    //Assign each index with the number of days
    int month [13] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
    // Set up the statement in case this is a valid date
    std::string date = "Month " + std::to_string(d) + " has " + std::to_string(month[(d>0)*d]) + " days ";
    // Set up string array containing three types of strings: Invalid, valid, or special case with month 2
    std::string line [3] = {"Invalid month number", date, "Month 2 has 28 or 29 days"};
    // The equation will return a as 2 if month 2, and return same number if it is valud, sets a as 0 if it is invalid.
    int a = ((d==2)*2) + ((d!=2)&&(((d>0)*(d<=12)*d)>0)) ;
    std::cout << line[a] << std::endl;
}


int main(){
    for (int i = -3; i<=12;i++){
    daysOfMonth(i);
    realfunction(i);
    }
}