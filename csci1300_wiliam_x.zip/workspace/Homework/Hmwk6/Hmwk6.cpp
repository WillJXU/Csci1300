#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <sstream>
#include <iomanip>
using namespace std;

/* Psedo-code
    1. Open the book file containting the book info
    2. For every line in the file seperate the author and the title using the 
        comma as a seperator
    3. Store the author and title to its appropriate array.

*/

int readBooks(std::string filename,std::string tit[], std::string auth[],int currstore,int cap){
    //Open stream and check if it exists
    std::ifstream bfile;
    bfile.open(filename);
    if (!bfile.is_open()){
        return -1;
    }
    std::string line;
    //Do a scan for each line an detect the author name and title. Split it into peoper tables, keep track of indexes
    int index = 0;
    while (getline(bfile,line)){
        //cout<<currstore+index<<','<<line<<endl;
        int commapos = line.find(',');
        tit[currstore+index] = line.substr(commapos+1,line.length()-commapos);
        auth[currstore+index] = line.substr(0,commapos);
        index++;
    }
    return index+currstore;
}


// Author, Title 

/* Psedo-code
    1. Open the rating file containting the rating info
    2. Seperate name and the rating
    3. Translate the name to an array index
    4. Store all of the ratings into the array of the name index
*/

int readRatings(std::string filename, std::string user[], int rating[][50],int tot, int rowcap,int colcap){
    //Open stream and check if it exists
    std::ifstream rfile;
    rfile.open(filename);
    if (!rfile.is_open()){
        return -1;
    }
    std::string line;
    //Scan each line in the stream and detect the comma and split it between users and ratings. 
    int usridx = tot;
    while (getline(rfile,line)){
        int commapos = line.find(',');
        user[usridx] = line.substr(0,commapos);
        std::cout<<user[usridx]<<"..."<<std::endl;
        int ratidx = 0;
        for (int i = commapos;i<line.length();i++){
            if (line[i] !=' '&&line[i] !=','){
                int a = line[i]-48;
                rating[usridx][ratidx] = a;
                ratidx++;
            }
        }
        usridx++;
    }
    return usridx;
}

/* Psedo-code
    1. Check if books are stored
    2. Print all book names
*/
void printAllBooks(std::string tit[],std::string aut[], int num){
    //Check if there are no books yet stored
    if (num<=0){
        std::cout<<"No books are stored"<<std::endl;
        return;
    }
    //Print off each item in tit (title) and book array
    std::cout<<"Here is a list of books"<<std::endl;
    for (int i = 0;i<num;i++){
        std::cout << tit[i] << " by " << aut[i] << std::endl;
    }
}

/* Psedo-code
    1. Check if database exist. 
    2. Match if name matches all of the content in the user table. If 
        none match, the user does not exist.
    3. Count all of the ratings in the ratings table that are not 0
*/
int getUserReadCount(std::string user,std::string usrtab[], int rattab[][50], int usernum, int booknum){
    //Check if at least 1 user is stored
    if (usernum<=0){
        std::cout<<user<<" does not exist in the database"<<std::endl;
        return -1;
    }
    //Find an item in array that matches with the user name. If found quit function. If not found stop the function
    int userindex = 0;
    for (int i = 0;i<usernum;i++){
        if (usrtab[i] == user){
            break;
        }
        if((usrtab[i] != user) && (userindex == usernum-1)){
            //std::cout<<user<<" does not exist in the database"<<std::endl;
            return -1;            
        }
        userindex++;
    }
    //Count the number of elements in array that aren't 0.
    int bookcount = 0;
    for (int i = 0;i<booknum;i++){
        if(rattab[userindex][i]!=0){
            bookcount++;
        }
    }
    return bookcount;
}
/* Psedo-code
    1. Check if both user and books exists 
    2. Find the user and access its rating table
    3. Add all of the rating, and count up the number of ratings that are not 0
    3. Divide the added ratings with the number of ratings
*/

double calcAvgRating(std::string title, std::string booktab[], int rating[][50],int usernum,int booknum){
    //Check if there are users stored and books stored
    if (usernum<=0||booknum<=0){
        std::cout<<title<<" does not exist in our database"<<std::endl;
        return -1;
    }  
    // Detect the title within the array, if at the end of the array the name does not match, kill the function
    int bookindex = 0;
    for (int i = 0;i<booknum;i++){
        if (booktab[bookindex] == title){
            break;
        }
        if((booktab[bookindex] != title) && (bookindex == booknum-1)){
            return -1;            
        }
        bookindex++;
    }
    //
    //Calculate the average by adding all of the averages and dividing them by the number books reviewd. 
    //I tried an alternative version which does not yeild a divide by 0 error, but it failed to accurately give out the correct average
    double bookcount = 0;
    double avg = 0 ;
    for (int i = 0;i<usernum;i++){
        if(rating[i][bookindex]!=0){
            bookcount++;
            avg = avg+(double)rating[i][bookindex]*1.00;
        }
    }
    return (avg)/bookcount;
}
//Do this everytime the task is finished
void displayMenu(){
  cout << "Select a numerical option:" << endl;
  cout << "======Main Menu=====" << endl;
  cout << "1. Read book file" << endl;
  cout << "2. Read user file" << endl;
  cout << "3. Print book list" << endl;
  cout << "4. Find number of books user rated" << endl;
  cout << "5. Get average rating" << endl;
  cout << "6. Quit" << endl;
}

/*
Loop and ask for player input and play the function for appropriate input.
*/


int main(int argc, char const *argv[]) {
    //Set up the "Global" values, they aren't actually global but functionally similar, that will be accessed by the functions
    int numBooks = 0;
    int numUsers = 0;
    //Assign the arrays
    std::string user[100];
    int rating[100][50];
    std::string title[100];
    std::string author[100];
    //Set up string value for the getline function
    std::string choice = "";
    while (choice != "6") {
        //Loop erases the choice string, and then displays menu. 
        choice = "";
        displayMenu();
        //Input and calc values are used for certain purpose
        //Input value is to be reused in case of user input is necessary for the function to continue
        //Calc stores the resulting calculation returned from the function
        std::string input = "";
        double calc= 0;
        getline(cin,choice);
        switch (stoi(choice)) {
            case 1:
            // read book file
                cout << "Enter a book file name:" << endl;
                getline(cin,input);
                numBooks = readBooks(input,title,author,numBooks,50);
                //Error when no books stored
                if (numBooks < 0){
                    numBooks = 0;
                    std::cout<<"No books saved to the database"<<std::endl;
                    break;                    
                }
                cout << "Total books in the database: " << numBooks << endl;
                break;
            case 2:
                // read user file
                cout << "Enter a rating file name:" << endl;
                getline(cin,input);
                numUsers = readRatings(input,user,rating,numUsers,100,50);
                //Error when no user stored
                if (numUsers < 0){
                    numUsers = 0;
                    std::cout<<"No users saved to database "<<std::endl;
                    break;
                }
                cout << "Total users in the database: " << numUsers << endl;
                break;
            case 3:
                // print the list of the books
                printAllBooks(title,author,numBooks);
                break;
            case 4:
                // find the number of books user read
                cout << "Enter username:" << endl;
                getline(cin,input);
                calc= getUserReadCount(input,user,rating,numUsers,numBooks);
                //If calc returns a natural integer value, give the number of books rated
                if (calc>=0){
                    cout << input<< " rated "<<abs(calc*(calc>0))<<" books"<<endl;
                    break;
                }
                break;
            case 5:
                // get the average rating of the book
                cout << "Enter book title:" << endl;
                getline(cin,input);
                calc = calcAvgRating(input, title, rating,numUsers,numBooks);
                //If calc returns a natural integer value, give the average rating
                if (calc >=0){
                    std::cout<<"The average rating for "<< input <<" is "<< setprecision (2) <<fixed<< calc <<std::endl; 
                    break;
                }
                break;
            case 6:
                // quit
                cout << "good bye!" << endl;
                choice = "6";
                break;
            default:
                cout << "invalid input" << endl;
        }
        std::cout<<std::endl;
    }
    return 0;
}