#ifndef LIBRARY_H
#define LIBRARY_H
#include <string>
#include "User.h"
#include "Book.h"
//Prototype for all data members and data functions
class Library{
    private:
        Book books[200];
        User users[200];
        int numBooks;
        int numUsers;
        int sizeBooks;
        int sizeUser;
    public:
        Library();
        int readBooks(std::string file);
        int readRatings(std::string file);
        void printAllBooks();
        int getCountReadBooks(std::string username);
        double calcAvgRating(std::string title);
        bool addUser(std::string username);
        bool checkOutBook(std::string user,std::string title,int newrat);
        void viewRatings(std::string user);
        void getRecommendations(std::string user);
};

#endif