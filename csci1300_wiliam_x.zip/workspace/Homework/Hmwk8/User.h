#ifndef USER_H
#define USER_H
#include <string>
//Prototype for all data members and data functions
class User{
    private:
        std::string username ;
        int ratings[200];
        int numRatings;
        int size = 200;
    public:
        User();
        User(std::string usrnm, int rat[], int nr);
        std::string getUsername();
        void setUsername(std::string usrnm);
        int getRatingAt(int index);
        bool setRatingAt(int index, int val);
        int getNumRatings();
        void setNumRatings(int num);
        int getSize();
};

#endif