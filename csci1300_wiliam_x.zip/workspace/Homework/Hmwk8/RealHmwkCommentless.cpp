#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
#include <iomanip> 
using namespace std;
class Book{
    private:
        std::string title;
        std::string author;
    public:
        Book();
        Book(std::string tit, std::string author);
        std::string getTitle()const;
        void setTitle(std::string title);
        std::string getAuthor()const;
        void setAuthor(std::string author);
};
Book::Book(){
    setAuthor("");
    setTitle("");
}
Book::Book(std::string tit, std::string author){
    setAuthor(author);
    setTitle(tit);
}
void Book::setAuthor(std::string newAuthor){
    author = newAuthor;
}
void Book::setTitle(std::string newTitle){
    title = newTitle;
}
std::string Book::getAuthor()const{
    return author;
}
std::string Book::getTitle()const{
    return title;
}
class User{
    private:
        std::string username ;
        int ratings[200];
        int numRatings;
        int size = 200;
    public:
        User();
        User(std::string usrnm, int rat[], int nr);
        std::string getUsername();
        void setUsername(std::string usrnm);
        int getRatingAt(int index);
        bool setRatingAt(int index, int val);
        int getNumRatings();
        void setNumRatings(int num);
        int getSize();
};
User::User(){
    setUsername("");    
    setNumRatings(0);
    size = 200;
    for(int i = 0;i<getSize();i++){
        ratings[i]=-1;
    }
}
User::User(std::string usrnm, int rat[], int nr){
    setUsername(usrnm);    
    setNumRatings(nr);
    for(int i = 0;i<getSize();i++){
        setRatingAt(i,rat[i]);
    }
}
std::string User::getUsername(){
    return username;
}
void User::setUsername(std::string usrnm){
    username = usrnm;   
}
int User::getRatingAt(int index){
    if((index<getSize())&&(index>=0)){
        return ratings[index];
    }
    return -1;
}
bool User::setRatingAt(int index, int val){
    if (((val>=0) && (val<=5))&&((index<getSize())&&(index>=0))){
        ratings[index] = val;
        return true;
    }
    return false;
}
int User::getNumRatings(){
    return numRatings;
}
void User::setNumRatings(int num){
    if(num<getSize()&&num>=0){
        numRatings = num;
    }
}
int User::getSize(){
    return size;
}
class Library{
    private:
        Book books[200];
        User users[200];
        int numBooks;
        int numUsers;
        int sizeBooks;
        int sizeUser;
    public:
        Library();
        int readBooks(std::string file);
        int readRatings(std::string file);
        void printAllBooks();
        int getCountReadBooks(std::string username);
        double calcAvgRating(std::string title);
        bool addUser(std::string username);
        bool checkOutBook(std::string user,std::string title,int newrat);
        void viewRatings(std::string user);
        void getRecommendations(std::string user);
};
Library::Library(){
    numBooks = 0;
    numUsers = 0;
}
int Library::readBooks(std::string file){
    std::ifstream f;
    f.open(file);
    if(!f.is_open()){
        return -1;
    }
    std::string line = "";
    int i = numBooks;
    while(getline(f,line)){
        if (line != "" && ((200-i)!=0)){
            Book lbook;
            int commapos = line.find(',');
            lbook.setTitle(line.substr(commapos+1,line.length()-commapos));
            lbook.setAuthor(line.substr(0,commapos));
            books[i] = lbook; 
            i++;
        }
    }
    numBooks = i;
    return i;
}
int Library::readRatings(std::string file){
    std::ifstream f;
    f.open(file);
    if(!f.is_open()){
        return -1;
    }
    int usridx = numUsers;
    std::string line = "";
    while (getline(f,line)){
        if (line != "" && ((200-usridx)!=0)){
            User luser;
            int commapos = line.find(',');
            luser.setUsername(line.substr(0,commapos));
            std::cout<<luser.getUsername()<<"..."<<std::endl;
            int irat = 0;
            for (int j = commapos;j<line.length();j++){
                if ((line[j] !=' ')&&(line[j] !=',')){
                    int a = line[j]-48;
                    luser.setRatingAt(irat,a);
                    irat++;
                }
            }
            luser.setNumRatings(irat+1);
            users[usridx] = luser;
            usridx++;
        }
    }   
    numUsers = usridx;
    return usridx;
}
void Library::printAllBooks(){
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return;
    }  
    if (numBooks<=0){
        std::cout<<"No books are stored"<<std::endl;
        return;
    }
    std::cout<<"Here is a list of books"<<std::endl;    
    for(int i=0;i<numBooks;i++){
        std::cout<<books[i].getTitle()<<" by "<<books[i].getAuthor()<<std::endl;
    }
}
int Library::getCountReadBooks(std::string username){
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return -1;
    }  
    int userindex = 0;
    for (int i = 0;i<numUsers;i++){
        if (users[i].getUsername() == username){
            break;
        }
        if((users[i].getUsername() != username) && (userindex == numUsers-1)){
            std::cout<<username<<" does not exist in the database"<<std::endl;
            return -2;            
        }
        userindex++;
    }
    int bookcount = 0;
    for (int i = 0;i<numBooks;i++){
        if(users[userindex].getRatingAt(i)>0){
            bookcount++;
        }
    }
    return bookcount;
}
double Library::calcAvgRating(std::string title){
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return -1;
    }  
    int bookindex = 0;
    for (int i = 0;i<numBooks;i++){
        if (books[bookindex].getTitle() == title){
            break;
        }
        if((books[bookindex].getTitle() != title) && (bookindex == numBooks-1)){
            std::cout<<title<< " does not exist in the database"<<std::endl;
            return -2;            
        }
        bookindex++;
    }
    double bookcount = 0;
    double avg = 0 ;
    for (int i = 0;i<numUsers;i++){
        if(users[i].getRatingAt(bookindex)!=0){
            bookcount++;
            avg = avg+(double)users[i].getRatingAt(bookindex)*1.00;
        }
    }
    return (avg)/bookcount;
}
bool Library::addUser(std::string username){
    int found = 0;
    for (int i = 0; i<numUsers;i++){
        std::string iuser = users[i].getUsername();
        if ( (((32*(iuser[0]<=90))+iuser[0]) == ((32*(username[0]<=90))+username[0]))&&(iuser.length() == username.length()) ){
            for (int j = 0; j < iuser.length();j++){
                if ( ((32*(iuser[j]<=90))+iuser[j]) != ((32*(username[j]<=90))+username[j]) ){
                    break;
                }
                found = (j == (iuser.length()-1));
            }
        }
    }
    if (numUsers == 200){
        std::cout << "Database full" <<std::endl;
        return false;
    }
    if (found == 0){
        User newU;
        newU.setUsername(username);
        users[numUsers] = newU;
        numUsers++;
        return true;
    }
    std::cout << username << " already exists in the database"<< std::endl;
    return false;
}
bool Library::checkOutBook(std::string user,std::string title,int newrat){
    std::string usertit[2] = {user,title};
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return false;
    }  
    int ubFound[2] = {0,0};
    int max = (numUsers*(numUsers>numBooks))+(numBooks*(numUsers<=numBooks));
    for (int i = 1;i <= max;i++){
        ubFound[0] = ubFound[0] + (i)*(users[i-1].getUsername() == user);
        ubFound[1] = ubFound[1] + (i)*(books[i-1].getTitle() == title);
        if(ubFound[0]*ubFound[1]>0){
            break;
        }
    }
    if (ubFound[0]==0||ubFound[1]==0||!(newrat<=5&&newrat>=0)){
        for(int i = 0; i<2;i++){
            if (ubFound[i]==0){
                std::cout<<usertit[i]<<" does not exist in the database"<<std::endl;
            }
        }
        if (!(newrat<=5&&newrat>=0)){
            std::cout<<newrat<< " is not valid"<<std::endl;
        }
        return false;
    }
    users[ubFound[0]-1].setNumRatings(users[ubFound[0]-1].getNumRatings()+1); 
    users[ubFound[0]-1].setRatingAt(ubFound[1]-1,newrat);
    return true;
}
void Library::viewRatings(std::string user){
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return;
    }
    int indx = -1;
    for(int i = 0;i<numUsers;i++){
        if (users[i].getUsername() == user){
            indx = i;
            break;
        }
    }
    if (indx ==-1){
        std::cout<<user<<" does not exist in the database"<<std::endl;
        return;
    }
    if (users[indx].getNumRatings()==0){
        std::cout<<user<<" has not rated any books yet"<<std::endl;
        return;
    }
    std::cout<<"Here are the books that "<< user<<" rated";
    int rated = 0;
    for(int i = 0 ;i < numBooks ;i++){
        if (users[indx].getRatingAt(i)>=1){
            std::cout<<std::endl;
            std::cout<<"Title : "<<books[i].getTitle()<<std::endl;
            std::cout<<"Rating : "<<users[indx].getRatingAt(i)<<std::endl;
            std::cout<<"-----";
            rated++;
            if (rated >= users[indx].getNumRatings()){
                break;
            }
        }
    }
    std::cout<<""<<std::endl;
    return;
}
void Library::getRecommendations(std::string user){
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return;
    }
    int indx = -1;
    for(int i = 0;i<numUsers;i++){
        if (users[i].getUsername() == user){
            indx = i;
            break;
        }
    }
    if (indx ==-1){
        std::cout<<user<<" does not exist in the database"<<std::endl;
        return;
    }    
    User u = users[indx];
    int ssd[200];
    for(int i = 0;i<numUsers;i++){
        User compuser = users[i];
        int difsquare = 0;
        if (getCountReadBooks(compuser.getUsername())>0 && (compuser.getUsername()!=u.getUsername())){
            for (int j = 0;j<numBooks;j++){
                    difsquare = difsquare + pow((compuser.getRatingAt(j)-u.getRatingAt(j)),2);
            }
            difsquare = difsquare + 1;
        }
        ssd[i] = difsquare;
    }
    int small = 0;
    for(int i = 0;i<numUsers;i++){
        if (ssd[i]>0){
            int notZeroAndSmall = (ssd[i]>=ssd[small])&&(ssd[small]!=0);
            small = small*(notZeroAndSmall)+i*(!notZeroAndSmall);
        }
    }
    User recuser = users[small];
    int incre = 0; 
    int rec = 0; 
    int rated = 0;
    Book reccobook[5];
    while(rated < (getCountReadBooks(recuser.getUsername()))){
        if(rec >= 5){
            break;
        }
        if (recuser.getRatingAt(incre)> 0){
            rated++;
        }
        if ((recuser.getRatingAt(incre)>= 3) && (u.getRatingAt(incre)<= 0)){
            reccobook[rec] = books[incre];
            rec++;
        }
        incre++;
    }
    if (rec == 0){
        std::cout<< "There are no recommendations for "<<user<<" at the present"<<std::endl;
        return;
    }
    std::cout<< "Here are the list of recommendations:" <<std::endl;
    for (int i = 0; i < rec;i++){
        std::cout<<reccobook[i].getTitle()<<" by "<<reccobook[i].getAuthor()<<std::endl;
    }
    return;
}
void displayMenu(){
     cout << "Select a numerical option:" << endl;
     cout << "======Main Menu=====" << endl;
     cout << "1. Read book file" << endl;
     cout << "2. Read user file" << endl;
     cout << "3. Print book list" << endl;
     cout << "4. Find number of books user rated" << endl;
     cout << "5. Get average rating" << endl;
     cout << "6. Add a User" << endl;
     cout << "7. Checkout a book" << endl;
     cout << "8. View Ratings" << endl;
     cout << "9. Get Recommendations" << endl;
     cout << "10. Quit" << endl;
}
int main(){
    Library lib;    
    std::string choice = "";
    while (choice != "10") {
        choice = "";
        displayMenu();
        std::string input = "";
        double calc= 0;
        bool succ;
        getline(cin,choice);
        switch (stoi(choice)) {
            case 1:{
                    int numBooks = 0;
                    cout << "Enter a book file name:" << endl;
                    getline(cin,input);
                    numBooks = lib.readBooks(input);
                    if (numBooks < 0){
                        numBooks = 0;
                        std::cout<<"No books saved to the database"<<std::endl;
                        break;                    
                    }
                    cout << "Total books in the database: " << numBooks << endl;
                }
                break;
            case 2:{
                    int numUsers = 0;
                    cout << "Enter a rating file name:" << endl;
                    getline(cin,input);
                    numUsers = lib.readRatings(input);
                    if (numUsers < 0){
                        numUsers = 0;
                        std::cout<<"No users saved to database "<<std::endl;
                        break;
                    }
                    cout << "Total users in the database: " << numUsers << endl;
                    }
                break;
            case 3:
                lib.printAllBooks();
                break;
            case 4:
                cout << "Enter username:" << endl;
                getline(cin,input);
                calc = lib.getCountReadBooks(input);
                if (calc>=0){
                    cout << input<< " rated "<<abs(calc*(calc>0))<<" books"<<endl;
                    break;
                }
                break;
            case 5:
                cout << "Enter book title:" << endl;
                getline(cin,input);
                calc = lib.calcAvgRating(input);
                if (calc >=0){
                    std::cout<<"The average rating for "<< input <<" is "<< setprecision (2) <<fixed<< calc <<std::endl; 
                    break;
                }
                break;
            case 6: 
                std::cout << "Enter username: "<<std::endl;
                getline(cin,input);
                succ = lib.addUser(input);
                if (succ){
                    std::cout<<"Welcome to the library "<< input <<std::endl;
                    break;
                }
                std::cout<<input<<" could not be added in the database"<<std::endl;
                break;
            case 7:{
                    std::string nametit[2];
                    std::cout << "Enter username: "<<std::endl;
                    getline(cin,nametit[0]);
                    std::cout << "Enter book title: "<<std::endl;
                    getline(cin,nametit[1]);
                    std::cout << "Enter rating for the book: "<<std::endl;
                    getline(cin,input);
                    succ = lib.checkOutBook(nametit[0],nametit[1],stoi(input));
                     if (succ){
                        std::cout<<"We hope you enjoyed your book. The rating has been updated"<<std::endl;
                        break;
                    }
                    std::cout<<nametit[0]<<" could not check out "<< nametit[1]<<std::endl;
                }
                break;
            case 8:
                std::cout << "Enter username: "<<std::endl;
                getline(cin,input);
                lib.viewRatings(input);
                break;
            case 9: 
                std::cout << "Enter username: "<<std::endl;
                getline(cin,input);
                lib.getRecommendations(input);            
                break;
            case 10:
                cout << "good bye!" << endl;
                choice = "10";
                break;
            default:
                cout << "invalid input" << endl;
        }
        std::cout<<std::endl;
    }
    return 0;
}