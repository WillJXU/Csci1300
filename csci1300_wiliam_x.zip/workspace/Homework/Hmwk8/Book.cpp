#include <iomanip>
#include "Book.h"
#include <string>
#include <iostream>
//Default constructor
Book::Book(){
    setAuthor("");
    setTitle("");
}
//Parameter constructor that isn't used anywhere in the code besides the code runner
Book::Book(std::string tit, std::string author){
    setAuthor(author);
    setTitle(tit);
}
//Sets the author value
void Book::setAuthor(std::string newAuthor){
    author = newAuthor;
}
//Sets the title
void Book::setTitle(std::string newTitle){
    title = newTitle;
}
//Returns author and title respectively
std::string Book::getAuthor()const{
    return author;
}
std::string Book::getTitle()const{
    return title;
}
