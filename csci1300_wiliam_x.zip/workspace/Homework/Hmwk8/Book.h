#ifndef BOOK_H
#define BOOK_H
#include <string>
//Prototype for all data members and data functions
class Book{
    private:
        std::string author;
        std::string title;
    public:
        Book();
        Book(std::string tit, std::string author);
        std::string getTitle()const;
        void setTitle(std::string title);
        std::string getAuthor()const;
        void setAuthor(std::string author);
};

#endif