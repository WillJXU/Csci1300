#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
#include <iomanip> 
using namespace std;

/* CSCI1300 Fall 2018
 Author: William Xue
 Recitation: 206 – Lucas Haynes
 Cloud9 Workspace Editor Link: <https://ide.c9.io/ .....>
 Project1
Prototype for all data members and data functions
*/
class Book{
    private:
        std::string author;
        std::string title;
    public:
        Book();
        Book(std::string tit, std::string author);
        std::string getTitle()const;
        void setTitle(std::string title);
        std::string getAuthor()const;
        void setAuthor(std::string author);
};
//Default constructor
Book::Book(){
    setAuthor("");
    setTitle("");
}
//Parameter constructor that isn't used anywhere in the code besides the code runner
Book::Book(std::string tit, std::string author){
    setAuthor(author);
    setTitle(tit);
}
//Sets the author value
void Book::setAuthor(std::string newAuthor){
    author = newAuthor;
}
//Sets the title
void Book::setTitle(std::string newTitle){
    title = newTitle;
}
//Returns author and title respectively
std::string Book::getAuthor()const{
    return author;
}
std::string Book::getTitle()const{
    return title;
}
//Prototype for all data members and data functions
class User{
    private:
        std::string username ;
        int ratings[200];
        int numRatings;
        int size = 200;
    public:
        User();
        User(std::string usrnm, int rat[], int nr);
        std::string getUsername();
        void setUsername(std::string usrnm);
        int getRatingAt(int index);
        bool setRatingAt(int index, int val);
        int getNumRatings();
        void setNumRatings(int num);
        int getSize();
};
User::User(){
    setUsername("");    
    setNumRatings(0);
    size = 200;
    for(int i = 0;i<getSize();i++){
        ratings[i]=-1;
    }
}
//Parameter, it's like default but parameter
User::User(std::string usrnm, int rat[], int nr){
    setUsername(usrnm);    
    setNumRatings(nr);
    for(int i = 0;i<getSize();i++){
        setRatingAt(i,rat[i]);
    }
}
//Returns username
std::string User::getUsername(){
    return username;
}
//Assign username
void User::setUsername(std::string usrnm){
    username = usrnm;   
}
//Returns Rating at an index
int User::getRatingAt(int index){
    if((index<getSize())&&(index>=0)){
        //std::cout <<"Rating that was set"<< ratings[index] << std::endl;
        return ratings[index];
    }
    return -1;
}
//Assigns a rating at an index
bool User::setRatingAt(int index, int val){
    if (((val>=0) && (val<=5))&&((index<getSize())&&(index>=0))){
        ratings[index] = val;
        return true;
    }
    return false;
}
//Return numRating
int User::getNumRatings(){
    return numRatings;
}
//Guess what, it assigns the num ratings. It's almost as if these are written in a pattern or something
void User::setNumRatings(int num){
    if(num<getSize()&&num>=0){
        numRatings = num;
    }
}
//Get's size that's gets used exclusively in the member functions, which is redundent in hindsight since member functions could just access private data members, but whatever.
int User::getSize(){
    return size;
}
//Library Prototype. I'm kinda pissed since if we did this in one file at the start I wouldn't need to write so many lines. I want ingenious back
class Library{
    private:
        Book books[200];
        User users[200];
        int numBooks;
        int numUsers;
        int sizeBooks;
        int sizeUser;
    public:
        Library();
        int readBooks(std::string file);
        int readRatings(std::string file);
        void printAllBooks();
        int getCountReadBooks(std::string username);
        double calcAvgRating(std::string title);
        bool addUser(std::string username);
        bool checkOutBook(std::string user,std::string title,int newrat);
        void viewRatings(std::string user);
        void getRecommendations(std::string user);
};
//Default Construct
Library::Library(){
    numBooks = 0;
    numUsers = 0;
}
int Library::readBooks(std::string file){
/* Psedo-code
1. Open the book file containting the book info
2. For every line in the file seperate the author and the title using the 
    comma as a seperator
3. Store the author and title to its appropriate data member.
*/
    //Open stream and check if it exists
    std::ifstream f;
    f.open(file);
    if(!f.is_open()){
        return -1;
    }
    std::string line = "";
    //Do a scan for each line an detect the author name and title. Split it into peoper tables, keep track of indexes
    int i = numBooks;
    while(getline(f,line)){
        if (line != "" && ((200-i)!=0)){
            Book lbook;//line book
            //Find the comma position
            int commapos = line.find(',');
            //Set the title and author
            lbook.setTitle(line.substr(commapos+1,line.length()-commapos));
            lbook.setAuthor(line.substr(0,commapos));
            //Put the line book in the B[]
            books[i] = lbook; 
            i++;
        }
    }
    numBooks = i;
    return i;
}
int Library::readRatings(std::string file){
/* Psedo-code
    1. Open the rating file containting the rating info
    2. Seperate name and the rating
    3. Store all of the ratings into the array of the user class's rating.
*/
    //Open stream and check if it exists
    std::ifstream f;
    f.open(file);
    if(!f.is_open()){
        return -1;
    }
    int usridx = numUsers;
    std::string line = "";
    //Scan each line in the stream and detect the comma and split it between users and ratings. 
    while (getline(f,line)){
        if (line != "" && ((200-usridx)!=0)){
            //Construct a line user function for each line
            User luser;
            //find comma
            int commapos = line.find(',');
            //set the username data memeber
            luser.setUsername(line.substr(0,commapos));
            std::cout<<luser.getUsername()<<"..."<<std::endl;
            int irat = 0;
            //loop through each character in the line and do whatever, change each character to an int value
            for (int j = commapos;j<line.length();j++){
                if ((line[j] !=' ')&&(line[j] !=',')){
                    int a = line[j]-48;
                    //std::cout<< a<<"|";
                    luser.setRatingAt(irat,a);
                    irat++;
                }
            }
            luser.setNumRatings(irat+1);
            //Insert the user class object into the U[] array for future use
            users[usridx] = luser;
            usridx++;
        }
    }   
    numUsers = usridx;
    return usridx;
}
void Library::printAllBooks(){
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return;
    }  
    //Check if there are any books
    if (numBooks<=0){
        std::cout<<"No books are stored"<<std::endl;
        return;
    }
    std::cout<<"Here is a list of books"<<std::endl;    
    //Print out all of the shit when there are books
    for(int i=0;i<numBooks;i++){
        std::cout<<books[i].getTitle()<<" by "<<books[i].getAuthor()<<std::endl;
    }
}
int Library::getCountReadBooks(std::string username){
    
/* Psedo-code
    1. Check if database exist. 
    2. Match if name matches all of the content in the user table. If 
        none match, the user does not exist.
    3. Count all of the ratings in the ratings table that are not 0
*/   
    //Check if at least 1 user is stored
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return -1;
    }  
    //Find an item in array that matches with the user name. If found quit function. If not found stop the function
    int userindex = 0;
    for (int i = 0;i<numUsers;i++){
        if (users[i].getUsername() == username){
            break;
        }
        if((users[i].getUsername() != username) && (userindex == numUsers-1)){
            std::cout<<username<<" does not exist in the database"<<std::endl;
            return -2;            
        }
        userindex++;
    }
    //Count the number of elements in array that aren't 0.
    int bookcount = 0;
    for (int i = 0;i<numBooks;i++){
        if(users[userindex].getRatingAt(i)>0){
            //std::cout<<users[userindex].getRatingAt(i)<<std::endl;
            bookcount++;
        }
    }
    return bookcount;
}
double Library::calcAvgRating(std::string title){
/* Psedo-code
    1. Check if both user and books exists 
    2. Find the user and access its rating table
    3. Add all of the rating, and count up the number of ratings that are not 0
    3. Divide the added ratings with the number of ratings
*/
    //Check if there are users stored and books stored
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return -1;
    }  
    // Detect the title within the array, if at the end of the array the name does not match, kill the function
    int bookindex = 0;
    for (int i = 0;i<numBooks;i++){
        if (books[bookindex].getTitle() == title){
            break;
        }
        if((books[bookindex].getTitle() != title) && (bookindex == numBooks-1)){
            std::cout<<title<< " does not exist in the database"<<std::endl;
            return -2;            
        }
        bookindex++;
    }
    //
    //Calculate the average by adding all of the averages and dividing them by the number books reviewd. 
    //I tried an alternative version which does not yeild a divide by 0 error, but it failed to accurately give out the correct average
    double bookcount = 0;
    double avg = 0 ;
    for (int i = 0;i<numUsers;i++){
        if(users[i].getRatingAt(bookindex)!=0){
            bookcount++;
            avg = avg+(double)users[i].getRatingAt(bookindex)*1.00;
        }
    }
    return (avg)/bookcount;
}
//Finally a new function to work with
/*Pseudo code
    1. Translate all of the characters in the string to undercase. and compare that to all of the undercase names in the user array
    2. If no match is found go to the check if database is full
    3. Make a new user class object and set its username, add it to the array, and update the numUser.
*/
bool Library::addUser(std::string username){
    int found = 0;
    //Translate both username and comparison username into undercase and check if the same
    for (int i = 0; i<numUsers;i++){
        std::string iuser = users[i].getUsername(); // iuser, or index user
        //Check if the first letter is the same, if so continue loop
        if ( (((32*(iuser[0]<=90))+iuser[0]) == ((32*(username[0]<=90))+username[0]))&&(iuser.length() == username.length()) ){
            //Check if the rest of the words are equal
            for (int j = 0; j < iuser.length();j++){
                if ( ((32*(iuser[j]<=90))+iuser[j]) != ((32*(username[j]<=90))+username[j]) ){
                    break;
                }
                found = (j == (iuser.length()-1));
            }
        }
    }
    //Check if dadabasefull
    if (numUsers == 200){
        std::cout << "Database full" <<std::endl;
        return false;
    }
    //If not found, do step 3 in the pseudo code
    if (found == 0){
        User newU;
        newU.setUsername(username);
        users[numUsers] = newU;
        numUsers++;
        return true;
    }
    std::cout << username << " already exists in the database"<< std::endl;
    return false;
}
/* Pseudo code
    1. Check if database initialized
    2. Find a match for both name and title.
    3. Update the numrating and the rating
*/
bool Library::checkOutBook(std::string user,std::string title,int newrat){
    std::string usertit[2] = {user,title};
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return false;
    }  
    int ubFound[2] = {0,0};
    //Find which is larger, numUsers or numBooks
    int max = (numUsers*(numUsers>numBooks))+(numBooks*(numUsers<=numBooks));
    //Go through all book and user array and check if they match, if both values are not zero break and progress to the next step
    for (int i = 1;i <= max;i++){
        ubFound[0] = ubFound[0] + (i)*(users[i-1].getUsername() == user);
        ubFound[1] = ubFound[1] + (i)*(books[i-1].getTitle() == title);
        if(ubFound[0]*ubFound[1]>0){
            break;
        }
    }
    //Error filter, check if either book or user are not found and if rating is valid. I want to die
    if (ubFound[0]==0||ubFound[1]==0||!(newrat<=5&&newrat>=0)){
        for(int i = 0; i<2;i++){
            if (ubFound[i]==0){
                std::cout<<usertit[i]<<" does not exist in the database"<<std::endl;
            }
        }
        if (!(newrat<=5&&newrat>=0)){
            std::cout<<newrat<< " is not valid"<<std::endl;
        }
        return false;
    }
    //Update num rating and update rating
    users[ubFound[0]-1].setNumRatings(users[ubFound[0]-1].getNumRatings()+1); 
    users[ubFound[0]-1].setRatingAt(ubFound[1]-1,newrat);
    return true;
}
/*pseudo code
    1. Check if database is initialized or the user exists
    2. Check if books were read
    3. Loop through the ratings list and list all that are not 0
*/
void Library::viewRatings(std::string user){
    //Check- You know what, you know exactly what this is. I'm not repeating this
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return;
    }
    //This too, just look at step 1
    int indx = -1;
    for(int i = 0;i<numUsers;i++){
        if (users[i].getUsername() == user){
            indx = i;
            break;
        }
    }
    if (indx ==-1){
        std::cout<<user<<" does not exist in the database"<<std::endl;
        return;
    }
    //Check if this dumbass hasn't read any books by using numRatings
    if (users[indx].getNumRatings()==0){
        std::cout<<user<<" has not rated any books yet"<<std::endl;
        return;
    }
    std::cout<<"Here are the books that "<< user<<" rated";
    int rated = 0;
    //Step 3
    for(int i = 0 ;i < numBooks ;i++){
        //Go thorugh and see if any of the books has been rated.
        if (users[indx].getRatingAt(i)>=1){
            std::cout<<std::endl;
            std::cout<<"Title : "<<books[i].getTitle()<<std::endl;
            std::cout<<"Rating : "<<users[indx].getRatingAt(i)<<std::endl;
            std::cout<<"-----";
            rated++;
            if (rated >= users[indx].getNumRatings()){
                break;
            }
        }
    }
    std::cout<<""<<std::endl;
    return;
}
/*pseudo code
    1. You know exactly what this step is
    2. Calculate all of the ssd value for each user that read and not itself
    3. Weed out and find the lowest ssd
    4. Get up to five recommendations and print them

*/
void Library::getRecommendations(std::string user){
    //Guess what it is, Einstein
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return;
    }
    //I'm only add this comment due to obligation and in an attempt to fool my grader to think I like to write pseudo codes
    int indx = -1;
    for(int i = 0;i<numUsers;i++){
        if (users[i].getUsername() == user){
            indx = i;
            break;
        }
    }
    /*Personally, I would vote to exile the person in the education board who suggested that comments are necessary. 
     Seriously, because of you I lose the elegant look of my code, now it's filled with these text that you have to squint just to look read it
    I already have a bunch of test code commented out to clog up the look of my code. I don't need to see more of this purple text color in this black back drop.
    */
    if (indx ==-1){
        std::cout<<user<<" does not exist in the database"<<std::endl;
        return;
    }    
    User u = users[indx];
    int ssd[200];//Array of all the ssd for each user
    for(int i = 0;i<numUsers;i++){
        User compuser = users[i];
        int difsquare = 0;//Initial difsquare value. If stored into ssd as 0, it means that they didn't read or is the same user
        if (getCountReadBooks(compuser.getUsername())>0 && (compuser.getUsername()!=u.getUsername())){
            for (int j = 0;j<numBooks;j++){
                    /*I square the difference. Seriously who the decided that you should add when 
                    the score is 0 or -1 for either side, doesn't that greatly change what the 
                    //actual value is? Having a 0 or -1 value means entirely different meaning 
                    //than getting numbers 1-5. Like 1-5 implies the quality, but 0 and -1 doesn't, 
                    //they just denote that the person hasn't read it, thus it's quality cannot 
                    //be determined. But now a 5/0 score means that the opinion of the two 
                    //user of the book is different. when it is indeterminable.
                    //This is like thinking someone with a deep hatred against writing pseudo code 
                    //is more simillar to a person who has never coded than someone who thinks 
                    //nothing of it. Basically, this is a stupid code and I spent approx. 
                    //2 hours alone in this section of the code simply because the write up did 
                    //not specify what to do when the rating is -1, and my logical thinking has 
                    hindered me rather than help me on the moodle testing..*/ 
                    difsquare = difsquare + pow((compuser.getRatingAt(j)-u.getRatingAt(j)),2);
            }
            //Oh, and a valid difsquare value will always be at least 1
            difsquare = difsquare + 1;
        }
        ssd[i] = difsquare;//Store one number in to other set of number
    }
    int small = 0;
    //Find the smallest ssd score
    for(int i = 0;i<numUsers;i++){
        if (ssd[i]>0){
            int notZeroAndSmall = (ssd[i]>=ssd[small])&&(ssd[small]!=0);
            small = small*(notZeroAndSmall)+i*(!notZeroAndSmall);
        }
    }
    User recuser = users[small];//Recuser with smallest ssd
    int incre = 0; //Increments the loop
    int rec = 0; // Increments the number of recommended books
    int rated = 0;//Increments the number of books rated
    Book reccobook[5];
    //While the number of rated books is less than the overall read book find at most 5 books
    while(rated < (getCountReadBooks(recuser.getUsername()))){
        //Quit when there are 5 books
        if(rec >= 5){
            break;
        }
        //Increment rated when a book has been found rated
        if (recuser.getRatingAt(incre)> 0){
            rated++;
        }
        //Add the recommended book to the list. Jesus I realized that I've been listening to the loop of the same song for 5 hour. When did I lost control of my life.
        if ((recuser.getRatingAt(incre)>= 3) && (u.getRatingAt(incre)<= 0)){
            reccobook[rec] = books[incre];
            rec++;
        }
        incre++;
    }
    //If there are nothing to recommend, you get nothing, despite the fact you 
    //could have gotten recommendation from the next best thing, but it's clear 
    //that at this point the code the assignment is asking from us is meant to be neither
    //effecient, practical, or expansive.
    if (rec == 0){
        std::cout<< "There are no recommendations for "<<user<<" at the present"<<std::endl;
        return;
    }
    std::cout<< "Here are the list of recommendations:" <<std::endl;
    for (int i = 0; i < rec;i++){
        std::cout<<reccobook[i].getTitle()<<" by "<<reccobook[i].getAuthor()<<std::endl;
    }
    return;
}
void displayMenu(){
     cout << "Select a numerical option:" << endl;
     cout << "======Main Menu=====" << endl;
     cout << "1. Read book file" << endl;
     cout << "2. Read user file" << endl;
     cout << "3. Print book list" << endl;
     cout << "4. Find number of books user rated" << endl;
     cout << "5. Get average rating" << endl;
     cout << "6. Add a User" << endl;
     cout << "7. Checkout a book" << endl;
     cout << "8. View Ratings" << endl;
     cout << "9. Get Recommendations" << endl;
     cout << "10. Quit" << endl;
}
int main(){
    Library lib;    
    //Set up the "Global" values, they aren't actually global but functionally similar, that will be accessed by the functions
    //Assign the arrays
    //Set up string value for the getline function
    std::string choice = "";
    while (choice != "10") {
        //Loop erases the choice string, and then displays menu. 
        choice = "";
        displayMenu();
        //Input and calc values are used for certain purpose
        //Input value is to be reused in case of user input is necessary for the function to continue
        //Calc stores the resulting calculation returned from the function
        std::string input = "";
        double calc= 0;
        bool succ;
        getline(cin,choice);
        switch (stoi(choice)) {
            case 1:{
                    int numBooks = 0;
                    // read book file
                    cout << "Enter a book file name:" << endl;
                    getline(cin,input);
                    numBooks = lib.readBooks(input);
                    //Error when no books stored
                    if (numBooks < 0){
                        numBooks = 0;
                        std::cout<<"No books saved to the database"<<std::endl;
                        break;                    
                    }
                    cout << "Total books in the database: " << numBooks << endl;
                }
                break;
            case 2:{
                    // read user file
                    int numUsers = 0;
                    cout << "Enter a rating file name:" << endl;
                    getline(cin,input);
                    numUsers = lib.readRatings(input);
                    //Error when no user stored
                    if (numUsers < 0){
                        numUsers = 0;
                        std::cout<<"No users saved to database "<<std::endl;
                        break;
                    }
                    cout << "Total users in the database: " << numUsers << endl;
                    }
                break;
            case 3:
                // print the list of the books
                lib.printAllBooks();
                break;
            case 4:
                // find the number of books user read
                cout << "Enter username:" << endl;
                getline(cin,input);
                calc = lib.getCountReadBooks(input);
                //If calc returns a natural integer value, give the number of books rated
                if (calc>=0){
                    cout << input<< " rated "<<abs(calc*(calc>0))<<" books"<<endl;
                    break;
                }
                break;
            case 5:
                // get the average rating of the book
                cout << "Enter book title:" << endl;
                getline(cin,input);
                calc = lib.calcAvgRating(input);
                //If calc returns a natural integer value, give the average rating
                if (calc >=0){
                    std::cout<<"The average rating for "<< input <<" is "<< setprecision (2) <<fixed<< calc <<std::endl; 
                    break;
                }
                break;
            case 6: 
                // God, just let this end, what are we here for? To suffer? Also this asks for the username. That's going to happen often in this code
                std::cout << "Enter username: "<<std::endl;
                getline(cin,input);
                succ = lib.addUser(input);
                if (succ){//If  [  S  U  C  C  ]  is true do this
                    std::cout<<"Welcome to the library "<< input <<std::endl;
                    break;
                }
                //If fail do this
                std::cout<<input<<" could not be added in the database"<<std::endl;
                break;
            case 7:{
                    std::string nametit[2];//String table that contains the name and title. The night affecting my mind, I'm childishly laughing at the fact this value has the word "tit" in it. I don't know how long I can retain my sanity.
                    std::cout << "Enter username: "<<std::endl;
                    getline(cin,nametit[0]);// heh, tit means mameries
                    std::cout << "Enter book title: "<<std::endl;
                    getline(cin,nametit[1]);
                    std::cout << "Enter rating for the book: "<<std::endl;
                    getline(cin,input);
                    succ = lib.checkOutBook(nametit[0],nametit[1],stoi(input));
                     if (succ){//Do this when succ
                        std::cout<<"We hope you enjoyed your book. The rating has been updated"<<std::endl;
                        break;
                    }//Do this if you sucked at inputing the proper values
                    std::cout<<nametit[0]<<" could not check out "<< nametit[1]<<std::endl;
                }
                break;
            case 8: //Case 8 and 9 are literally the same thing with different 
                    //function. I'm not going to elaborate on the obvious because
                    //I'm currently waiting for death or for this code to pass 
                    //in the code runner. And I am getting impatient right now.
                std::cout << "Enter username: "<<std::endl;
                getline(cin,input);
                lib.viewRatings(input);
                break;
            case 9: 
                std::cout << "Enter username: "<<std::endl;
                getline(cin,input);
                lib.getRecommendations(input);            
                break;
            case 10:
                // quit
                cout << "good bye!" << endl;
                choice = "10";
                break;
            default:
                cout << "invalid input" << endl;
        }
        std::cout<<std::endl;
    }
    return 0;
}