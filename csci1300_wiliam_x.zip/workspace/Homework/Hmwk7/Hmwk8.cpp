#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
#include <iomanip> 
#include "User.h"
#include "Book.h"
#include "Library.h"

using namespace std;

void displayMenu(){
     cout << "Select a numerical option:" << endl;
     cout << "======Main Menu=====" << endl;
     cout << "1. Read book file" << endl;
     cout << "2. Read user file" << endl;
     cout << "3. Print book list" << endl;
     cout << "4. Find number of books user rated" << endl;
     cout << "5. Get average rating" << endl;
     cout << "6. Add a User" << endl;
     cout << "7. Checkout a book" << endl;
     cout << "8. View Ratings" << endl;
     cout << "9. Get Recommendations" << endl;
     cout << "10. Quit" << endl;
}

int main(){
    Library lib;    
    //Set up the "Global" values, they aren't actually global but functionally similar, that will be accessed by the functions
    //Assign the arrays
    //Set up string value for the getline function
    std::string choice = "";
    while (choice != "10") {
        //Loop erases the choice string, and then displays menu. 
        choice = "";
        displayMenu();
        //Input and calc values are used for certain purpose
        //Input value is to be reused in case of user input is necessary for the function to continue
        //Calc stores the resulting calculation returned from the function
        std::string input = "";
        double calc= 0;
        bool succ;
        getline(cin,choice);
        switch (stoi(choice)) {
            case 1:{
                    int numBooks = 0;
                    // read book file
                    cout << "Enter a book file name:" << endl;
                    getline(cin,input);
                    numBooks = lib.readBooks(input);
                    //Error when no books stored
                    if (numBooks < 0){
                        numBooks = 0;
                        std::cout<<"No books saved to the database"<<std::endl;
                        break;                    
                    }
                    cout << "Total books in the database: " << numBooks << endl;
                }
                break;
            case 2:{
                    // read user file
                    int numUsers = 0;
                    cout << "Enter a rating file name:" << endl;
                    getline(cin,input);
                    numUsers = lib.readRatings(input);
                    //Error when no user stored
                    if (numUsers < 0){
                        numUsers = 0;
                        std::cout<<"No users saved to database "<<std::endl;
                        break;
                    }
                    cout << "Total users in the database: " << numUsers << endl;
                    }
                break;
            case 3:
                // print the list of the books
                lib.printAllBooks();
                break;
            case 4:
                // find the number of books user read
                cout << "Enter username:" << endl;
                getline(cin,input);
                calc = lib.getCountReadBooks(input);
                //If calc returns a natural integer value, give the number of books rated
                if (calc>=0){
                    cout << input<< " rated "<<abs(calc*(calc>0))<<" books"<<endl;
                    break;
                }
                break;
            case 5:
                // get the average rating of the book
                cout << "Enter book title:" << endl;
                getline(cin,input);
                calc = lib.calcAvgRating(input);
                //If calc returns a natural integer value, give the average rating
                if (calc >=0){
                    std::cout<<"The average rating for "<< input <<" is "<< setprecision (2) <<fixed<< calc <<std::endl; 
                    break;
                }
                break;
            case 6: 
                std::cout << "Enter a username: "<<std::endl;
                getline(cin,input);
                succ = lib.addUser(input);
                if (succ){
                    std::cout<<"Welcome to the library "<< input <<std::endl;
                    break;
                }
                std::cout<<input<<" could not be added in the database"<<std::endl;
                break;
            case 7:{
                    std::string nametit[2];
                    std::cout << "Enter a username: "<<std::endl;
                    getline(cin,nametit[0]);
                    std::cout << "Enter a book title: "<<std::endl;
                    getline(cin,nametit[1]);
                    std::cout << "Enter a rating for the book: "<<std::endl;
                    getline(cin,input);
                    succ = lib.checkOutBook(nametit[0],nametit[1],stoi(input));
                     if (succ){
                        std::cout<<"We hope you enjoyed your book. The rating has been updated"<< input <<std::endl;
                        break;
                    }
                    std::cout<<nametit[0]<<" could not check out "<< nametit[1]<<std::endl;
                }
                break;
            case 8: 
                std::cout << "Enter a username: "<<std::endl;
                getline(cin,input);
                lib.viewRatings(input);
                break;
            case 9: 
                std::cout << "Enter a username: "<<std::endl;
                getline(cin,input);
                lib.getRecommendations(input);            
                break;
            case 10:
                // quit
                cout << "good bye!" << endl;
                choice = "6";
                break;
            default:
                cout << "invalid input" << endl;
        }
        std::cout<<std::endl;
    }
    return 0;
}