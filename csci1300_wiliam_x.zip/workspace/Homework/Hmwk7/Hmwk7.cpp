#include <iostream>
#include <string>
#include <fstream>
#include "User.h"
#include "Book.h"
using namespace std;

/* Psedo-code
    1. Open the book file containting the book info
    2. For every line in the file seperate the author and the title using the 
        comma as a seperator
    3. Store the author and title to its appropriate data member.

*/
//Second function same as the first. It reads book. I literally just copy pasted nearly the same code
int readBooks(std::string filename, Book B[],int stor, int cap){
    //Open stream and check if it exists
    std::ifstream f;
    f.open(filename);
    if(!f.is_open()){
        return -1;
    }
    std::string line = "";
    int i = stor;
    //Do a scan for each line an detect the author name and title. Split it into peoper tables, keep track of indexes
    while(getline(f,line)){
        Book lbook;//line book
        //Find the comma position
        int commapos = line.find(',');
        //Set the title and author
        lbook.setTitle(line.substr(commapos+1,line.length()-commapos));
        lbook.setAuthor(line.substr(0,commapos));
        //Put the line book in the B[]
        B[i] = lbook; 
        i++;
    }
    return i;
}

// Author, Title 

/* Psedo-code
    1. Open the rating file containting the rating info
    2. Seperate name and the rating
    3. Store all of the ratings into the array of the user class's rating.
*/
int readRatings(std::string filename, User U[], int stor, int cap){
    //Open stream and check if it exists
    std::ifstream f;
    f.open(filename);
    if(!f.is_open()){
        return -1;
    }
    int usridx = stor;
    std::string line = "";
    //Scan each line in the stream and detect the comma and split it between users and ratings. 
    while (getline(f,line)){
        //Construct a line user function for each line
        User luser;
        //find comma
        int commapos = line.find(',');
        //set the username data memeber
        luser.setUsername(line.substr(0,commapos));
        std::cout<<luser.getUsername()<<"..."<<std::endl;
        int irat = 0;
        //loop through each character in the line and do whatever, change each character to an int value
        for (int j = commapos;j<line.length();j++){
            if ((line[j] !=' ')&&(line[j] !=',')){
                int a = line[j]-48;
                //std::cout<< a<<"|";
                luser.setRatingAt(irat,a);
                irat++;
            }
        }
        luser.setNumRatings(irat+1);
        //Insert the user class object into the U[] array for future use
        U[usridx] = luser;
        usridx++;
    }   
    return usridx;
}
//Print all Books, who would have guessed
void printAllBooks(Book arr[],int num){
    //Check if there are any books
    if (num<=0){
        std::cout<<"No books are stored"<<std::endl;
        return;
    }
    std::cout<<"Here is a list of books"<<std::endl;    
    //Print out all of the shit when there are books
    for(int i=0;i<num;i++){
        std::cout<<arr[i].getTitle()<<" by "<<arr[i].getAuthor()<<std::endl;
    }
}



void displayMenu(){
  cout << "Select a numerical option:" << endl;
  cout << "======Main Menu=====" << endl;
  cout << "1. Read book file" << endl;
  cout << "2. Read user file" << endl;
  cout << "3. Print book list" << endl;
  cout << "4. Find number of books user rated" << endl;
  cout << "5. Get average rating" << endl;
  cout << "6. Quit" << endl;
}
int main(){
    //Set up the "Global" values, they aren't actually global but functionally similar, that will be accessed by the functions
    int numBooks = 0;
    int numUsers = 0;
    //Assign the arrays
    Book booktab[200];
    User usertab[200];
    //Set up string value for the getline function
    std::string choice = "";
    while (choice != "6") {
        //Loop erases the choice string, and then displays menu. 
        choice = "";
        displayMenu();
        //Input and calc values are used for certain purpose
        //Input value is to be reused in case of user input is necessary for the function to continue
        //Calc stores the resulting calculation returned from the function
        std::string input = "";
        double calc= 0;
        getline(cin,choice);
        switch (stoi(choice)) {
            case 1:
            // read book file
                cout << "Enter a book file name:" << endl;
                getline(cin,input);
                numBooks = readBooks(input,booktab,numBooks,200);
                //Error when no books stored
                if (numBooks < 0){
                    numBooks = 0;
                    std::cout<<"No books saved to the database"<<std::endl;
                    break;                    
                }
                cout << "Total books in the database: " << numBooks << endl;
                break;
            case 2:
                // read user file
                cout << "Enter a rating file name:" << endl;
                getline(cin,input);
                numUsers = readRatings(input,usertab,numUsers,200);
                //Error when no user stored
                if (numUsers < 0){
                    numUsers = 0;
                    std::cout<<"No users saved to database "<<std::endl;
                    break;
                }
                cout << "Total users in the database: " << numUsers << endl;
                break;
            case 3:
                // print the list of the books
                printAllBooks(booktab,numBooks);
                break;
            /*case 4:
                // find the number of books user read
                cout << "Enter username:" << endl;
                getline(cin,input);
                calc= getUserReadCount(input,user,rating,numUsers,numBooks);
                //If calc returns a natural integer value, give the number of books rated
                if (calc>=0){
                    cout << input<< " rated "<<abs(calc*(calc>0))<<" books"<<endl;
                    break;
                }
                break;
            case 5:
                // get the average rating of the book
                cout << "Enter book title:" << endl;
                getline(cin,input);
                calc = calcAvgRating(input, title, rating,numUsers,numBooks);
                //If calc returns a natural integer value, give the average rating
                if (calc >=0){
                    std::cout<<"The average rating for "<< input <<" is "<< setprecision (2) <<fixed<< calc <<std::endl; 
                    break;
                }
                break;*/
            case 6:
                // quit
                cout << "good bye!" << endl;
                choice = "6";
                break;
            default:
                cout << "invalid input" << endl;
        }
        std::cout<<std::endl;
    }
    return 0;
}