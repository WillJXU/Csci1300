#include <iomanip>
#include "User.h"
#include <string>
#include <iostream>
/*        
        std::string username;
        int ratings[];
        int numRatings;
        int size;
*/
//Default constructer, sets name blank, numRating 0 and size 200, and all rating elements -1
User::User(){
    setUsername("");    
    setNumRatings(0);
    size = 200;
    for(int i = 0;i<getSize();i++){
        ratings[i]=-1;
    }
}
//Parameter, it's like default but parameter
User::User(std::string usrnm, int rat[], int nr){
    setUsername(usrnm);    
    setNumRatings(nr);
    for(int i = 0;i<getSize();i++){
        setRatingAt(i,rat[i]);
    }
}
//Returns username
std::string User::getUsername(){
    return username;
}
//Assign username
void User::setUsername(std::string usrnm){
    username = usrnm;   
}
//Returns Rating at an index
int User::getRatingAt(int index){
    if(index<getNumRatings()&&index>=0){
        return ratings[index];
    }
    return -1;
}
//Assigns a rating at an index
bool User::setRatingAt(int index, int val){
    if (((val>=0) && (val<=5))&&((index<getSize())&&(index>=0))){
        ratings[index] = val;
        return true;
    }
    return false;
}
//Return numRating
int User::getNumRatings(){
    return numRatings;
}
//Guess what, it assigns the num ratings. It's almost as if these are written in a pattern or something
void User::setNumRatings(int num){
    if(num<getSize()&&num>=0){
        numRatings = num;
    }
}
//Get's size that's gets used exclusively in the member functions, which is redundent in hindsight since member functions could just access private data members, but whatever.
int User::getSize(){
    return size;
}
