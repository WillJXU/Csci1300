#include <iomanip>
#include "Library.h"
#include "User.h"
#include "Book.h"
#include <string>
#include <fstream>
#include <iostream>
#include <cmath>
Library::Library(){
    numBooks = 0;
    numUsers = 0;
}
int Library::readBooks(std::string file){
/* Psedo-code
1. Open the book file containting the book info
2. For every line in the file seperate the author and the title using the 
    comma as a seperator
3. Store the author and title to its appropriate data member.
*/
    //Open stream and check if it exists
    std::ifstream f;
    f.open(file);
    if(!f.is_open()){
        return -1;
    }
    std::string line = "";
    //Do a scan for each line an detect the author name and title. Split it into peoper tables, keep track of indexes
    int i = numBooks;
    while(getline(f,line)){
        if (line != "" && ((200-i)!=0)){
            Book lbook;//line book
            //Find the comma position
            int commapos = line.find(',');
            //Set the title and author
            lbook.setTitle(line.substr(commapos+1,line.length()-commapos));
            lbook.setAuthor(line.substr(0,commapos));
            //Put the line book in the B[]
            books[i] = lbook; 
            i++;
        }
    }
    numBooks = i;
    return i;
}
int Library::readRatings(std::string file){
/* Psedo-code
    1. Open the rating file containting the rating info
    2. Seperate name and the rating
    3. Store all of the ratings into the array of the user class's rating.
*/
    //Open stream and check if it exists
    std::ifstream f;
    f.open(file);
    if(!f.is_open()){
        return -1;
    }
    int usridx = numUsers;
    std::string line = "";
    //Scan each line in the stream and detect the comma and split it between users and ratings. 
    while (getline(f,line)){
        if (line != "" && ((200-usridx)!=0)){
            //Construct a line user function for each line
            User luser;
            //find comma
            int commapos = line.find(',');
            //set the username data memeber
            luser.setUsername(line.substr(0,commapos));
            std::cout<<luser.getUsername()<<"..."<<std::endl;
            int irat = 0;
            //loop through each character in the line and do whatever, change each character to an int value
            for (int j = commapos;j<line.length();j++){
                if ((line[j] !=' ')&&(line[j] !=',')){
                    int a = line[j]-48;
                    //std::cout<< a<<"|";
                    luser.setRatingAt(irat,a);
                    irat++;
                }
            }
            luser.setNumRatings(irat+1);
            //Insert the user class object into the U[] array for future use
            users[usridx] = luser;
            usridx++;
        }
    }   
    numUsers = usridx;
    return usridx;
}
void Library::printAllBooks(){
    //Check if there are any books
    if (numBooks<=0){
        std::cout<<"No books are stored"<<std::endl;
        return;
    }
    std::cout<<"Here is a list of books"<<std::endl;    
    //Print out all of the shit when there are books
    for(int i=0;i<numBooks;i++){
        std::cout<<books[i].getTitle()<<" by "<<books[i].getAuthor()<<std::endl;
    }
}
int Library::getCountReadBooks(std::string username){
    
/* Psedo-code
    1. Check if database exist. 
    2. Match if name matches all of the content in the user table. If 
        none match, the user does not exist.
    3. Count all of the ratings in the ratings table that are not 0
*/   
    //Check if at least 1 user is stored
    if (numUsers<=0){
        std::cout<<username<<" does not exist in the database"<<std::endl;
        return -1;
    }
    //Find an item in array that matches with the user name. If found quit function. If not found stop the function
    int userindex = 0;
    for (int i = 0;i<numUsers;i++){
        if (users[i].getUsername() == username){
            break;
        }
        if((users[i].getUsername() != username) && (userindex == numUsers-1)){
            //std::cout<<user<<" does not exist in the database"<<std::endl;
            return -2;            
        }
        userindex++;
    }
    //Count the number of elements in array that aren't 0.
    int bookcount = 0;
    for (int i = 0;i<numBooks;i++){
        if(users[userindex].getRatingAt(i)!=0){
            bookcount++;
        }
    }
    return bookcount;
}
double Library::calcAvgRating(std::string title){
    
/* Psedo-code
    1. Check if both user and books exists 
    2. Find the user and access its rating table
    3. Add all of the rating, and count up the number of ratings that are not 0
    3. Divide the added ratings with the number of ratings
*/
    //Check if there are users stored and books stored
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return -1;
    }  
    // Detect the title within the array, if at the end of the array the name does not match, kill the function
    int bookindex = 0;
    for (int i = 0;i<numBooks;i++){
        if (books[bookindex].getTitle() == title){
            break;
        }
        if((books[bookindex].getTitle() != title) && (bookindex == numBooks-1)){
            return -1;            
        }
        bookindex++;
    }
    //
    //Calculate the average by adding all of the averages and dividing them by the number books reviewd. 
    //I tried an alternative version which does not yeild a divide by 0 error, but it failed to accurately give out the correct average
    double bookcount = 0;
    double avg = 0 ;
    for (int i = 0;i<numUsers;i++){
        if(users[i].getRatingAt(bookindex)!=0){
            bookcount++;
            avg = avg+(double)users[i].getRatingAt(bookindex)*1.00;
        }
    }
    return (avg)/bookcount;
}
bool Library::addUser(std::string username){
    int found = 0;
    for (int i = 0; i<numUsers;i++){
        if (users[i].getUsername() == username){
            found = 1;
            break;
        }
    }
    if (numUsers == 200){
        std::cout << "Database full" <<std::endl;
        return false;
    }
    if (found = 0 ){
        User newU;
        newU.setUsername(username);
        users[numUsers] = newU;
        numUsers++;
        return true;
    }
    std::cout << username << " already exists in the database"<< std::endl;
    return false;
}
bool Library::checkOutBook(std::string user,std::string title,int newrat){
    std::string usertit[2] = {user,title};
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return false;
    }  
    int ubFound[2] = {0,0};
    int max = numUsers*(numUsers>numBooks)+numBooks*!(numUsers>numBooks);
    for (int i = 0;i < max;i++){
        ubFound[0] = ubFound[0] + i*(users[i].getUsername() == user);
        ubFound[1] = ubFound[1] + i*(books[i].getTitle() == title);
        if(ubFound[0]*ubFound[1]>0){
            break;
        }
    }
    if (ubFound[0]==0||ubFound[1]==0||!(newrat<=5&&newrat>=0)){
        for(int i = 0; i<2;i++){
            if (ubFound[i]==0){
                std::cout<<usertit[i]<<" does not exist in the database"<<std::endl;
            }
        }
        if (!(newrat<=5&&newrat>=0)){
            std::cout<<newrat<< " is not valid"<<std::endl;
        }
        return false;
    }
    users[ubFound[0]].setRatingAt(ubFound[1],newrat);
    return true;
}

void Library::viewRatings(std::string user){
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return;
    }
    int indx = -1;
    for(int i = 0;i<numUsers;i++){
        if (users[i].getUsername() == user){
            indx = i;
            break;
        }
    }
    if (indx ==-1){
        std::cout<<user<<" does not exist in the database"<<std::endl;
        return;
    }
    if (users[indx].getNumRatings()==0){
        std::cout<<user<<" has not rated any books yet"<<std::endl;
        return;
    }
    std::cout<<"Here are the books that "<< user<<" rated"<<std::endl;
    int rated = 0;
    for(int i = 0 ;rated <= users[indx].getNumRatings();i++){
        if (users[indx].getRatingAt(i)!=0){
            std::cout<<"Title: "<<books[i].getTitle()<<std::endl;
            std::cout<<"Rating: "<<users[indx].getRatingAt(i)<<std::endl;
            rated++;
        }
    }
}

void Library::getRecommendations(std::string user){
    if (numUsers<=0||numBooks<=0){
        std::cout<<"Database has not been fully initialized"<<std::endl;
        return;
    }
    int indx = -1;
    for(int i = 0;i<numUsers;i++){
        if (users[i].getUsername() == user){
            indx = i;
            break;
        }
    }
    if (indx ==-1){
        std::cout<<user<<" does not exist in the database"<<std::endl;
        return;
    }    
    User u = users[indx];
    if (u.getNumRatings()==0){
        //std::cout<<user<<" has not rated any books yet"<<std::endl;
        return;
    }
    double ssd[200];

    for(int i = 0;i<numUsers;i++){
        User compuser = users[i];
        double difsquare = 0;
        if (compuser.getNumRatings()!=0){
            int rated = 0;
            for (int j = 0;rated<=compuser.getNumRatings();j++){
                if (compuser.getRatingAt(j)!= 0){
                    difsquare = difsquare + pow(compuser.getRatingAt(j)-u.getRatingAt(j),2);
                    rated++;
                }
            }
        }
        ssd[i] = difsquare;
    }
    int small = 0;
    for(int i = 0;i<200;i++){
        small = small*(ssd[i]>ssd[small])+i*!(ssd[i]>ssd[small]);
    }
    User recuser = users[small];
    int incre = 0;
    int rec = 0;
    int rated = 0;
    while(rated < recuser.getNumRatings() && rec < 5){
        if (recuser.getRatingAt(incre)!= 0){
            rated++;
        }
        if (recuser.getRatingAt(incre)>= 3 && u.getRatingAt(incre)== 0){
            std::cout<<books[incre].getTitle()<<" by "<<books[incre].getAuthor()<<std::endl;
            rec++;
        }
        incre++;
    }
}
