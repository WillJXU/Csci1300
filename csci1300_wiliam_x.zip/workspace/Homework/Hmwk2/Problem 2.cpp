#include <iostream>
#include <stdio.h>      /* printf, NULL */
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <assert.h>
#include <iomanip> 

#include<cstdio>

/* Algorithm: Translate inferiror celcius unit to superior fahrenheit unit.
    Function, celsiusToFahrenheit, gets an integer of "cel", short for celcius. 
    Output on console cel *1.8+3.2
    
    Input: Temp in Celcius unit
    Output:The temperature of cel in fahrenheit is (cel * 1.8 + 32)
    Return: Nothing

*/

void celsiusToFahrenheit(int cel){
    std::cout <<"The temperature of "<< cel<< " in fahrenheit is " << std::setprecision(2) <<std::fixed<<cel * 1.8 + 32<< std::endl;
}

int main(){
    for (int a = 0;a < 2;a++){//For Loop for the 2 test cases with random input
        int temp = rand()%10;
        celsiusToFahrenheit(temp);
    }
}