#include <iostream>
#include <stdio.h>      /* printf, NULL */
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <assert.h>

/* Algorithm: Predict future population for a given initial population and growth data.
    Function, population, gets an integer of "intpop" for initial population. 
    Value t is set up, repersenting the number of seconds in a year. 365 days*24 hours*60 minutes*60 minutes
    Return the sum of the initial population and the growth of the population after a year.
    
    Input: Temp in Celcius unit
    Output: Nothing
    Return: Population of initial population after a year in integer

*/

int population(int intpop){
    int t = 365*24*60*60;
    return intpop+t/8-t/12+t/27;
}


int main(){
    for (int a = 0;a < 2;a++){//For Loop for the 2 test cases with random input
        int initial = rand()%100000;
        std::cout <<"Initial population:"<< initial << std::endl;
        std::cout << population(initial) << std::endl;
    }
   // std::cout << population(1000000) << std::endl;
}