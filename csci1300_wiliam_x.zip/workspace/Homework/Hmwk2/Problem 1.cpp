#include <iostream>
#include <stdio.h>      /* printf, NULL */
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <assert.h>
/* Algorithm: Convert seconds to H:M:S format
    Function, convertSeconds, gets an integer of "s" seconds. 
    ts repersents the seconds portion of the time, and it is given by finding the remainder of s divided by 60.
    tm repersents the minute portion of the time, and it is given by subtracting s by ts and dividing it by 60 and finding the remainder divided by 60.
    th repersets the hour portion of the time, and it is given by subtracting the non-hour portion of s and dividing it by 3600, or 60*60. 
    Output on console ts, tm, th in the format.
    
    Input: Time in seconds
    Output: th hour(s) tm minute(s) ts second(s)
    Return: Nothing. I think the assignment made this fairly clear.

*/
void convertSeconds(int s){
    int ts = s%(60);
    int tm = ((s-ts)/(60))%60;
    int th = ((s-tm*60-ts)/(60*60));
    std::cout << th<<" hour(s) "<<tm<<" minute(s) "<<ts<< " second(s) "<<std::endl;
    assert(s == th*60*60+tm*60+ts);    
}


int main(){
    for (int a = 0;a < 2;a++){//For Loop for the 2 test cases with random input
        int timeInSeconds = rand()%100000;
        std::cout << timeInSeconds << std::endl;
        convertSeconds(timeInSeconds);
    }
}