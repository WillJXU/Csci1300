#include <iostream>
#include <stdio.h>      /* printf, NULL */
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <assert.h>
#include <cmath>

/* Algorithm: Calculate luminocity given the double value distance and brightness.
    Function, luminosity, gets a double of "d" and "b" for distance and brightness respectively. 
    Integer value lum is set up, repersenting the luminosity derived from the equation, 4*Pi*b*d^2
    Return lum
    
    Input: Distance and Brightness (Both double) 
    Output: Nothing
    Return: Luminosity in integer values.

*/

int luminosity(double b, double d){
    int lum = 4*M_PI*b*pow(d,2);
    return lum;
}


int main(){
    for (int a = 0;a < 2;a++){//For Loop for the 2 test cases with random input
        double distance = rand()%10;
        double brightness = rand()%50;
        std::cout << "If distance is "<<distance<<" and  brightness is " << brightness<<" then luminosity is:"<<std::endl;
        //This line outputs the luminosity value for the given parameters.
        std::cout << luminosity(distance,brightness) << std::endl;
    }
    //std::cout << population(1000000) << std::endl;
}