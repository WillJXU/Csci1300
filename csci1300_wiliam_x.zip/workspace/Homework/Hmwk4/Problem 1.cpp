//THIS IS THE PROTOTYPE CODE, GO TO THE OTHER PROBLEM 1 FILE FOR THE REAL CODE 
//USED IN THE CODE RUNNER WHICH INCLUDES THE PSEUDO CODE.

#include <iostream>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
#include <string>
using namespace std;

//Value list

int winstate = 0;
int plr = 1; // 1 is player, 0 is robot
int gamepoints[2] = {0,0};
int turntotal[2] = {0,0};
int maxpointwin = 20;
std::string pRefer[2][2] = {{"computer","computer"},{"human","you"}};
/**
* rollDice
* returns a random integer between 1 and 6, works as rolling a dice.
* return value, int number (1-6)
*/
int rollDice()
{
return random() % 6 + 1;
}


/* robot
    A function that decides the action of the robot
*/
char robot(int point){
    if (point<=10){
        return 'y';
    }
    else {
        return 'n';
    }
}

// your 3 + functions go in here ...

int rollanalysis(int turnpoint, int play){
    int result = rollDice();
    switch (result){
        case 1:
        case 6:
        case 3:
            gamepoints[play] = (result == 3)*15;    
            turntotal[play] = 0;
        break;
        case 2:
        case 4:
        case 5:
            gamepoints[play] = gamepoints[play] + result;
            turntotal[play] = turntotal[play]+result;
        break;
    }
    std::cout << pRefer[plr][1] <<" rolled a "<< result << std::endl;
    std::cout << pRefer[plr][1] <<" turn total is "<< turntotal[play] << std::endl; 
    if (turntotal[plr] == 0){
        std::cout << "computer: " << gamepoints[0]<< std::endl;
        std::cout << "human: "<< gamepoints[1]<< std::endl;
        std::cout<<std::endl;
    }
    return turntotal[play];
}

/*turn
    A function that organizes the turn so that it loops itself to perform the game
*/

int turn(int replay,int play){
    if (gamepoints[0]>= maxpointwin or gamepoints[1]>= maxpointwin ){
        return 10;
    }
    char cont;
    if (play){
        std::string response [2] = {"Do you want to roll a dice (Y/N)?","Do you want to roll a dice again? (Y/N)?"};
        std::cout << response[replay] <<std::endl;
        std::cin >> cont;
    }
    else{
        cont = robot(turntotal[0]);
    }
    if (cont == 'y' || cont == 'Y'){
        int result = rollanalysis(turntotal[play],play);
        if (gamepoints[plr]>= maxpointwin){
            std::cout << "computer: " << gamepoints[0]<< std::endl;
            std::cout << "human: "<< gamepoints[1]<< std::endl;
            std::cout<<std::endl;
            std::cout<<"Congratulations! "<< pRefer[play][0] <<" won this round of jeopardy dice!";
            result = 0;
            winstate = 1;
        }
        if (result){
            turn(1,plr);
        }
        return 0;
    }
    else if(cont == 'n' || cont == 'N'){
        turntotal[plr] = 0;
        return 0;
    }
    else {
        std::cout << "That's not a valid input numb nut" << std::endl;
        turn(0,0);
        return 0;
    }
}

/**
* game ()
* driver function to play the game
* the function does not return any value
*/

void game()
{
    while (winstate==0){
        std::cout<< "It is now "<< pRefer[plr][0] <<"'s turn"<<std::endl;
        std::cout<<std::endl;
        int a = turn(0,plr);
        if (a == 10){
            break;
        }
        plr = (plr==0);
    }
// your solution goes here
}

int main()
{
    std::cout << "Welcome to Jeopardy Dice!" << std::endl;

    // start the game!
    game();
    return 0;
}