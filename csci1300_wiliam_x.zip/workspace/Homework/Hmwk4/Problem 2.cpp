// CSCI1300 Fall 2018
// Author: William Xue
// Recitation: 206 – Lucas Haynes
// Cloud9 Workspace Editor Link: <https://ide.c9.io/ .....>
// Project1
/*
    1. Cout the set up, if first player is computer, refer the value plr as 
        computer, else human.
    2. Go in a game loop, check if game value is true, other wise skip to 
        step 3.
        2a. Check player if Number of marble is 1, if so change game value to 
            false, ending the loop. Go to step 3.
        2b. Allow player to make decision, if robot use the function to decide.
            2ba. If robot and smart, loop and increment the power value of 2 
                until it is over half of the number of marbles. Subtract number 
                of marble with the current power of 2. Return that value.
            2bb. If robot and not smart, select random number from 1 to half 
                the number of marble rounded down.
        2c. Subtract the decision from the number of global marble value.
        2d. Change the current player value to the non player.
        2e. Go to 2a.
    3. Post result. 
*/
#include<iostream>
#include <string>
#include <cmath>
#include <math.h> 
std::string plr[2] = {"Computer","Human"};
std::string yesno[2] = {"No","Yes"};

//Value list
int marb; // # of marbles
bool smode; //Smart mode
bool fmove; // First move, true if player is first
bool game = 1; // Allows the loop if true. Ends game if turned false

// Rolls random number
int rollDice()
{
return random() % (marb/2) + 1;
}

// Analyze the turn if it is valid or not. Subtract current marb value 
// with the turn
int moveanalysis(int n){
    if (n <= marb/2){
        //Subtract n from marb if valid
        marb -= n;
    }   
    else{
        // Loop back function if move invalid
        std::cout <<"Wrong Move. You can only choose between 1 to "<< marb/2<<std::endl;
        std::cout << "Your move. Marbles remaining: "<<marb <<std::endl;
        std::cin >> n;
        moveanalysis(n);
    }
}

int robot(){
    int take; //Take is the value to be returned
    if (smode){
        int root=0;
        int n;
        while ((pow(2,root)-1)<(marb/2)){
            ++root;
            n = marb-(pow(2,root)-1);
        }
        take = n;
    }
    else {
        take = rollDice();
    }
    if (take == 0) {
        take = 1;
    }
    return take;
}

int marbleRun(int marble, bool smart, bool first){
    //set up
    smode = smart;
    fmove = !first;
    marb = marble;
    std::cout << "Lets start the game!"<<std::endl;
    std::cout << "Initial size is: " << marble<<std::endl;
    std::cout << "First player to play: " << plr[fmove]<<std::endl;
    std::cout << "Is computer in smart mode? " <<yesno[smode]<<std::endl;
    //Looping the game
    while(game){
        int took;//Took is the number of marbles took in the valid turn
        //If player, ask for an input
        if (fmove){
            std::cout << "Your move. Marbles remaining: "<<marb <<std::endl;
            int n;
            std::cin >> n; 
            took = n;
            moveanalysis(n);
        }
        //If robot consult the function
        else{
            std::cout <<"Computer is playing.."<<std::endl;
            took = robot();
            moveanalysis(took);
            std::cout<<"Computer took "<<took<<std::endl;
        }
        std::cout<<"Remaining marbles: "<<marb<<std::endl;
        //If only one marble, end game
        if (marb <= 1){
            game = 0;
            std::cout << "You lose. Computer won";
        }
        fmove = !fmove;
    }
}

int main(){
    marbleRun(11,1,1);
}