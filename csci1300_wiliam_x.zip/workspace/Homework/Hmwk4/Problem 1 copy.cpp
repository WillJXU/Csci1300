// CSCI1300 Fall 2018
// Author: William Xue
// Recitation: 206 – Lucas Haynes
// Cloud9 Workspace Editor Link: <https://ide.c9.io/ .....>
// Project1
/*
1. Start the game with the first player's turn.
    1a. Check if game point of player exceeds 100, if over 100 go to 1c. 
        Else change who plays, if human change to robot, if robot turn to human
    1b. Give the player an option to roll the dice or not 
        If N, add the turn results to the game point. End the turn and post the 
            turn result. Go back to 1a.
        If Y, Roll a random number 
            If roll is 2,4,or 5 add that to the turn total. Go back to 1b
            If roll is 1, or 6, end the turn and set turn total to 0. Go back to 1b
            If roll is 3, end the turn and the turn total to 15. Go back to 1b
    1c. End the game.
*/
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
#include <string>
using namespace std;
//Value list
int winstate = 0; // if winstate is 0, that means the game has not concluded yet. Used to signal the computer to stop the game once changed
int plr = 1; // 1 is player, 0 is robot
int gamepoints[2] = {0,0};// This table stores the total game point for each player. Index 0 is the robot, index 1 is the human
int turntotal[2] = {0,0};// This table stores the total turn point for each player. Index 0 is the robot, index 1 is the human
const int maxpointwin = 100; // The maximum number of points needed to end the game
std::string pRefer[2][3] = {{"computer","Computer","Computer"},{"human","You","Your"}};//A string table that is used to reference the pronouns/names of the current player
/*
* rollDice
* returns a random integer between 1 and 6, works as rolling a dice.
* return value, int number (1-6)
*/
int rollDice(){
    return random() % 6 + 1;
}
// your 3 + functions go in here ...
/* robot
    A function that decides the action of the robot. It takes the turn point as the input and returns a char decision
*/
char robot(int point){
    if (point<10){
        return 'y';
    }
    else {
        return 'n';
    }
}
/* roll analysis
    Takes in the turn point and acts accordingly to the rules of the game.
    Adjusts the game total and turn total
*/
int rollanalysis(int turnpoint){
    int result = rollDice();// Randomly generated value from 1 to 6
    int turnend = 0; // Turn end signals if the turn ends, thus the turn loop stops
    switch (result){
        // Case 1,3,6 results in a turn end. And negates the turn total
        // In case 3, the turn total negates the turn total and adds 15 
        case 1:
        case 3:
        case 6:
            gamepoints[plr] = gamepoints[plr]-turntotal[plr]+(15*(result==3));    
            turntotal[plr] = (15*(result==3));
            turnend = 1;
        break;
        // Case 2,4,5 adds the result to the game point and continues the loop
        case 2:
        case 4:
        case 5:
            gamepoints[plr] = gamepoints[plr] + result;
            turntotal[plr] = turntotal[plr]+result;
            turnend = 0;
        break;
    }
    std::cout << pRefer[plr][1] <<" rolled a "<< result << std::endl;
    std::cout << pRefer[plr][2] <<" turn total is "<< turntotal[plr] << std::endl; 
    
    // When the turn ends, print out the current state of the game.
    if (turnend == 1){
        std::cout << "computer: " << gamepoints[0]<< std::endl;
        std::cout << "human: "<< gamepoints[1]<< std::endl;
        std::cout<<std::endl;
        turntotal[plr] = 0;
    }
    return turntotal[plr];
}
/*turn
    A function that organizes the turn so that it loops itself to perform the game
*/

std::string response [2] = {"Do you want to roll a dice (Y/N)?:","Do you want to roll again (Y/N)?:"};
int turn(int replay){
    // Every time a turn begins, before the rest of the turn is performed check 
    //if either player reached 100.
    if (gamepoints[0]>= maxpointwin or gamepoints[1]>= maxpointwin ){
        return 10;
    }
    char cont;/* Cont means "continue". Indicates the Y or N character values
               Only ask for an input if it is player's turn. Otherwise assign 
               the robot function. cont using */
    if (plr){
        std::cout << response[replay] <<std::endl;
        std::cin >> cont;
    }
    else{
        cont = robot(turntotal[0]);
    }
    if (cont == 'y' || cont == 'Y'){
        // Get the roll result you got
        int result = rollanalysis(turntotal[plr]);
        //In a case maxpointwin is achieved, set win state to 1 to end the 
        //game loop
        if (gamepoints[plr]>= maxpointwin){
            std::cout<<"Congratulations! "<< pRefer[plr][0] <<" won this round of jeopardy dice!";
            result = 0;
            winstate = 1;
        }
        if (result){
            turn(1);
        }
        return 0;
    }
    //If N print the turn result
    else if(cont == 'n' || cont == 'N'){
        turntotal[plr] = 0;
        std::cout << "computer: " << gamepoints[0]<< std::endl;
        std::cout << "human: "<< gamepoints[1]<< std::endl;
        std::cout<<std::endl;
        return 0;
    }
    // In any case other than Y or N, reply with this and repeat the loop 
    else {
        std::cout << "That's not a valid input numb nut" << std::endl;
        turn(0);
        return 0;
    }
}
/*
 game ()
 driver function to play the game
 the function does not return any value
*/
void game(){
    std::cout << "Welcome to Jeopardy Dice!" << std::endl;
    std::cout << std::endl;
    // Perform a while loop that repeats the game until winstate is no longer 1.
    while (winstate==0){
        std::cout<< "It is now "<< pRefer[plr][0] <<"'s turn"<<std::endl;
        std::cout<<std::endl;
        int a = turn(0);
        //If a is 10 since turn returned 10, break the script so the algorigm ends
        if (a == 10){
            break;
        }
        // At the end of each turn change plr to 1 to 0 or 0 to 1.
        plr = (plr==0);
    }
}
int main(){
    game();
    return 0;
}