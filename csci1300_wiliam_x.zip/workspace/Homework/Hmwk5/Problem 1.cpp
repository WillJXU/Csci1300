// CSCI1300 Fall 2018
// Author: William Xue
// Recitation: 206 – Lucas Haynes
// Cloud9 Workspace Editor Link: <https://ide.c9.io/ .....>
// Project1

/* Pseudo code
        simScore: 
    1. Check if the two parameters are the same and not length 0, if 
        not return 0
    2. Loop through each character and increment a value, "match", every time 
        they are the same.
    3. Return match divided by the parameter length.
    
        analyzer:
    1. Check if all parameters have the more than 0 character, if not return
    2. Check if all the strains are equal in length, if not return
    3. Check if the comparison strain is shorter than one of the test strain, 
        if not return
    4. Loop for all three strings.
        4a. Check for each character position in the string up to the string 
            length minus the comparison length using the simScore function. 
            Get a return value of simScore with parameter of the substring of 
            the strain and the comparison strain.
        4b. Check if the returned value from simScore is larger than the current
            largest comparison value, which was initially 0. If larger, replace 
            the new simScore returned value as the largest comparison value. 
        There should be at 3 largest comparison value at the end of the loop.
    5. Compare all three comparison value and determine the largest one.
    6. See if any other of the three comparison value matches in value with 
        the largest value, and then output those value's strain that matches 
        the largest value.
*/

#include <string>
#include<iostream>
#include <cmath>
using namespace std;
double simScore(string dna, string comp){
    double match = 0;//Value that shows how many characters match
    if (comp.length()*dna.length()== 0){//Check if length is not 0
        return 0;
    }
    for (int i=0;i<comp.length();i++){//Check for all characters and add one to "match" if character match.
        match = match + (dna[i]==comp[i]);
    }
    return (match/dna.length())*(comp.length()==dna.length());// Return match divided by comp strain length
}
void analyzer(string s1, string s2, string s3, string samp){
    string st[3];// String array containing the strain strings
    double simscorerate[3] = {0,0,0};//Double array which will contain the largest simScore of the strain
    st[0] = s1;st[1] = s2;st[2] = s3;//Table assignment
    if((st[0].length()*st[1].length()*st[2].length()*samp.length())==0){//Check if length of all parameter is not 0
        std::cout<<"Genome and sequence cannot be empty."<<std::endl;
        return;
    }
    if( ( st[0].length()!=st[1].length() )||( st[0].length()!=st[2].length() ) ){//Check if length is the same for all
        std::cout<<"Genome length does not match."<<std::endl;
        return;
    }
    if (st[0].length()<samp.length()){//Check if samp length is smaller than all of the other lengths
        std::cout<<"Sequence length must be smaller than genome length."<<std::endl;
        return;
    }
    for(int i = 0;i<=2;i++){//Loop to get the highest simScore value for all of the strings in the table
        for (int txtpos = 0;txtpos<(st[0].length()-samp.length());txtpos++){
            double newsimscore = simScore(st[i].substr(txtpos,samp.length()),samp);
            int x = (newsimscore>simscorerate[i]);
            simscorerate[i]= (newsimscore*x)+(simscorerate[i]*!x);
        }
    }
    double large = simscorerate[0];//Sets the first comparison value to be the first in the array.
    for(int i = 0;i<2;i++){//Goes across all values in the array and decide which is the largest
        large =  large*(large>simscorerate[i+1])+simscorerate[i+1]*(large<simscorerate[i+1])+large*(large==simscorerate[i+1]);
    }
    for(int i = 0;i<=2;i++){// Check if any other value is equal to the largest number. If so output the prompt. 
        if (simscorerate[i]==large){
            std::cout<<"Genome "<<i+1<<" is the best match."<<std::endl;   
        }
    }
    return;
}

int main(){//I copied off the test cases from the code runner.
    std::cout<<simScore("TAGGA","TAGGA")<<std::endl;
    std::cout<<simScore("TAGAA","TAGGA")<<std::endl;
    std::cout<<simScore("TAG","TAGGA")<<std::endl;
    std::cout<<simScore("ATAGA","TAGGA")<<std::endl;
    std::cout<<simScore("","TAGGA")<<std::endl;
    std::cout<<simScore("TAGGA","")<<std::endl;
    
    string g1 = "TAAGGCA";string g2 = "TCTGGGC";string g3 = "CTAATAT";string seq = "AAG";analyzer(g1,g2,g3,seq);
    std::cout<<std::endl;
    g1 = "TAAGGCA";g2 = "TACCTAC";g3 = "AGCCAGA";seq = "TCT";analyzer(g1,g2,g3,seq);
    std::cout<<std::endl;
    analyzer("AC","AC","AC","AC");
    std::cout<<std::endl;
    g1 = "CATCATAATTAGCACGTTGTTGGTACCTAGAGACCAACTTAC";g2 = "TGGAGACCCACCCGTTACTTCTGACAGACAGAAGTGAGCGAT";g3 = "CCTAACGTGTGGCCACGCGGGAGAAGAGGTTTACCATTCTGC";seq = "TCTTTTA";analyzer(g1,g2,g3,seq); 
    std::cout<<std::endl;
    analyzer("AAG","TGC","GATTACA","TAC");
    g1 = "AAG";g2 = "TGC";g3 = "TAC";seq = "CCCCCATAG";analyzer(g1,g2,g3,seq);
    analyzer("","TGC","","TTA");
    analyzer("TTC","GCC","TCT","");
}