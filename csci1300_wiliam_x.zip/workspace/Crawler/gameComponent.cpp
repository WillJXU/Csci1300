//#ifndef HELPER_H
//#define HELPER_H
#include <string>
#include <fstream>
#include <iostream>
#include <cmath>
#include <stdlib.h>  
#include <ctime>
#include <chrono>
#include <thread>
#include "items.cpp"


/*
This cpp file contains the 4 most important classes in the game

coords, which is meant to be a 2d coordinate data type, which 
can be manipulated using different functions
Map is used to keep track of the collision and position of the player relative to the map
player contains all the information of the player
game contains loader functions

*/

class coord{
    private:
        int x = 0;
        int y = 0;
        bool tf = true;
    public:
        coord(){
            x = 0;
            y = 0;
            tf = true;
        }
        int getx(){
            return x;
        }
        int gety(){
            return y;
        }
        void setx(int pos){
            x = pos;
            getx();
        }
        void sety(int pos){
            y = pos;
            gety();
        }
        void setxy(int posx,int posy){
            setx(posx);
            sety(posy);
        }
        void move(int disx, int disy){
            setxy(getx()+disx,gety()+disy);
        }
        double getDistance(coord pos){
            return sqrt(pow(pos.x-x,2)+pow(pos.y-y,2));
        }
        coord settf(bool b){
            tf = b;
        }
        bool gettf(){
            return tf;
        }

};//Custom value class
class Map{
    private:
        int sizex;
        int sizey;
        std::string mapstring;
    public:
        std::string tfile;
        Map(){//Default constructor
            mapstring = "";
            sizex = 10;
            sizey = 10;
        }
        Map(std::string txtfile,int rendcoll){//Rendcoll = 0 for other map files, rendcoll = 1 for render, rendcoll = 2 for collision
            std::ifstream f;
            std::string ifs[3] = {"","Render.txt","Collision.txt"};
            std::cout<<txtfile + ifs[rendcoll]<<std::endl;
            f.open(txtfile + ifs[rendcoll]);
            if (!f.is_open()){
                errorCout("txtfile", "map", "Bad director or file name");
                f.close();
                return;
            }
            tfile = txtfile;
            int y = 0;
            int x = 0;
            std::string str;
            while(getline(f,str)){
                mapstring = mapstring + str;
                x = str.length()*(x<str.length())+x*(x>=str.length());
                y++;
            }
            sizex = x;
            sizey = y;
            f.close();
        }
        bool isWithinDim(coord c){
            if ((c.getx()>sizex||c.getx()<0)||(c.gety()>sizey||c.gety()<0)){
                return false;
            }
            return true;
        }
        
        void setDimension(int x, int y){
            sizex = abs(x);
            sizey = abs(y);
        }
        bool printMap(std::string outTxt){
            if (mapstring.length() == 0){
                return false;
            }
            std::ofstream f;
            f.open(outTxt);
            if (!f.is_open()){
                errorCout("none", "printMap", "tfile insuffecient");
                return false;
            }
            for (int i = 0;i<sizey;i++){
                f << mapstring.substr(i*sizex,sizex)<< std::endl;
            }
            f.close();
        }
        bool updatePixel(coord pos, char c,std::string outtxt){
            std::ofstream f;
            f.open(outtxt);
            if (!f.is_open()){
                f.close();
                errorCout("none", "updatePixel", "tfile insuffecient");
            }
            std::string copy = mapstring;
            copy[pos.gety()*sizex+pos.getx()-1] = c;
            for (int i = 0;i<sizey;i++){
                f << copy.substr(i*sizex,sizex)<<std::endl;
            }
        }
        char getCharOnCoord(coord p){
            if (p.getx()<=sizex&&p.gety()<=sizey){
                return mapstring[p.gety()*sizex+p.getx()-1];
            }
        }
        void showOnDisp(int x, int y, int xdim, int ydim){
            std::ifstream f;
            f.open("Display.txt");
            if (!f.is_open()){
                errorCout("none", "updatePixel", "tfile insuffecient");
                return;
            } 
            for (int i = 0;i<10;i++){
                std::cout<<""<<std::endl;
            }
            std::string str;
            int count = 0;
            int xdisp = (xdim-1)/2;
            int ydisp = (ydim-1)/2;
            std::cout<<"[=================]"<<std::endl;
            while(getline(f,str)){
                if ((count > y-ydisp-1) && (count <= y+ydisp)){
                    int px = x-xdisp-1;
                    std::cout<< str.substr((0*(px<=0))+(px*((px>0||px>=sizex)))+(sizex*(px>=sizex)),xdim)<<std::endl;
                }
                count++;
            }
            std::cout<<"[=================]"<<std::endl;
        }
};//Contains information of the map, including collision and render txt files
class player{
    private:
        coord point;//Current position
        coord spawn;//Position after death
        char skin = 'o';//Character appearence
        std::string fileaccess;//Which save file is being used
        int screendimy = 6;//Dimenstion of the screen on the y axis
        std::string in;//Genetic string value for string storage
        //Private members originally in the deprecated games class;
        weapon swordtable[40];
        int swordLen = 0;
        food foodlist[40];
        int foodLen = 0;
    public:
        bool Boss[5] = {false,false,false,false,false};
        std::string Winv[40]; //Weapon inventory
        int WinvLen = 0;
        std::string Finv[40]; //Food inventory
        int FinvLen = 0;
        //User attribute
        int coin = 0;//Unused coins
        int speed = 5;//How much input movement that can be made
        int attk=3;//Minimum of the attack
        int attkrng = 2;//Range of attack, above the minimum 
        int critchance = 10;//Chance of a crit
        int critdamage = 10;//When critical, how much damage is inflicted
        int maxHealth = 10;
        int health = 10;
        int defence = 10;//Initial defence value
        int currDef = 10;//Current defence. Value used to calculate defence effect
        int harden = 1;//Harden, how much the defence hardes in a move, deprecated
        int keys = 0;//Keys, deprecated
        int totcoin = 0;//Total coin
        std::string wep = "";
        //Map Data, the current location of the user
        Map currMap;//Rendering
        Map coll;//Map collision
        Map disp = Map("Display.txt",0);//Target display, where the place gets rendered
        //Member functions
        player(){
        }
        player(std::string stats){//Load user stats
            ifstream f;
            f.open(stats);
            getline(f,in);
            attk = stoi(in.substr(18,in.length()));
            getline(f,in);
            maxHealth = stoi(in.substr(18,in.length()));
            getline(f,in);
            health = stoi(in.substr(18,in.length()));
            getline(f,in);
            defence = stoi(in.substr(18,in.length()));
            getline(f,in);
            speed = stoi(in.substr(18,in.length()));
            getline(f,in);
            coin = stoi(in.substr(18,in.length()));
            getline(f,in);
            totcoin = stoi(in.substr(18,in.length()));
            getline(f,in);
            int d = in.find(",");
            int x = stoi(in.substr(18,d-18));
            int y = stoi(in.substr(d+1,in.length()-d+1));
            std::cout<<x<<","<<y<<std::endl;
            setPoint(x,y);
            getline(f,in);
            currMap = Map(in.substr(18,in.length()),1);
            coll = Map(in.substr(18,in.length()),2);
            getline(f,in);
            skin = in[18];
            f.close();
        }//Loads up player with previous stats
        weapon getWeaponInfo(int i){
            if (i>=0&&i<swordLen){
                return swordtable[i];
            }
            return swordtable[0];
        }//Return weapon object from table
        food getFoodInfo(int i){
            if (i>=0&&i<foodLen){
                return foodlist[i];
            }
            return foodlist[0];
        }//Returns food object from table
        std::string getStats(std::string s){
            std::string in;
            ifstream f;
            f.open("Data/CurrData/visStats.txt");
            while(getline(f,in)){
                if (in.find(s)!=std::string::npos){
                    std::cout<<"The value of "<<s<<" is "<<in.substr(18,in.length()-18)<<std::endl;
                    f.close();
                    return in.substr(18,in.length()-18);
                }
            }
        }
        bool healthupdate(int damage){
            health = health-(damage-damage*(currDef/100));;
            std::cout<<"Your health is now "<<health<<std::endl;
            currDef = defence;
            return (health<=0);
        }//Update health
        void changeFileAccess(std::string f){
            fileaccess = f;
        }//Change the file access of the player
        std::string getFileAccess(){
            return fileaccess;
        }//returns what the player's file access is
        coord setSpawn(int x, int y){
            spawn.setxy(x,y);
            updateValueFromFile("Data/CurrData/visStats.txt","Spawn Loc.",""+to_string(x)+","+to_string(y)+"");
        }//Sets the spawn position as well as the map
        coord setPoint(int x, int y){
            point.setxy(x,y);
        }//Sets the current position of the player
        coord setPoint(std::string c){
            int x = stoi(c.substr(c.find(":")+1,c.length()-(c.find(":")+1)));
            int y = stoi(c.substr(0,c.find(":")));
            std::cout<<"x,y is "<<x<<", "<<y<<std::endl;
            point.setxy(x,y-1);
        }//Sets the current position of the player
        int findDoor(std::string s){
            ifstream f;
            f.open("Data/CurrData/door.txt");
            while (getline(f,in)){
                if (in == currMap.tfile){
                    while (getline(f,in)){
                        if (in.find(s)!= std::string::npos){
                            int i = stoi(in.substr(14,in.length()-14));
                            std::cout<<"Boss code for this door is "<<i<<std::endl;
                            return i;
                        }
                    }
                }
            }
        }
        coord movecharacter(std::string input,Map m){
            int limit = (speed*(input.length()>speed)+input.length()*(input.length() <= speed));
            for (int i = 0;i<limit;i++){
                int movet[5][2] = {{0,1},{-1,0},{1,0},{0,-1},{0,0}};
                if ((input[i]-48)%2!=0){
                    return point.settf(false);    
                }
                int c = (input[i]-48)/2-1;
                if (input[i]-48 == 0){
                    c = 5;
                }
                coord p = point;
                p.move(movet[c][0],movet[c][1]);
                if (currMap.isWithinDim(p)&&(coll.getCharOnCoord(p)!='#')){
                    if (coll.getCharOnCoord(p)!='='){
                        point.move(movet[c][0],movet[c][1]);
                        currMap.updatePixel(point,skin*(i==(limit-1))+('o')*(i!=(limit-1)),disp.tfile);
                    }
                    else{
                        int d = findDoor(to_string(point.gety()-1)+to_string(point.getx()));
                        if (Boss[d]){
                            point.move(movet[c][0],movet[c][1]);
                            currMap.updatePixel(point,skin*(i==(limit-1))+('o')*(i!=(limit-1)),disp.tfile);                            
                        }
                    }
                }
                m.showOnDisp(point.getx(),point.gety(),screendimy*4,screendimy);
            }
            return point.settf(true);
        }
        coord getPoint(){
            return point;   
        }//Returns the current position as a coord
        std::string getPointString(){
            std::cout<<"Current Position: "<<point.getx()<<","<<point.gety()<<std::endl;
            return to_string(point.gety()+1)+":"+to_string(point.getx());
        }//Returns the current position as a string
        void readNote(){
            std::ifstream f;
            std::string s;
            f.open("misc/questionmark.txt");
            while(getline(f,s)){
                if (s == currMap.tfile){
                    while(getline(f,s)){
                        std::string note = std::to_string(point.gety()+1)+":"+std::to_string(point.getx());
                        if (s.find(note) != -1){
                            getline(f,s);
                            if (s.find("[")>=0){
                                for (int i = 0;i<10;i++){
                                    std::cout<<""<<std::endl;
                                }
                                std::cout<<"|            +==(_________________________)==+            |"<<std::endl;
                                std::cout<<"|               |||||!V!V!V!V!V!V!V!V!|||||               |"<<std::endl;
                                std::cout<<""<<std::endl;
                            }
                            while(getline(f,s)){
                                if (s.find("]")!=-1){
                                    std::cout<<""<<std::endl;
                                    std::cout<<"|               |||||!^!^!^!^!^!^!^!^!|||||               |"<<std::endl;
                                    std::cout<<"|            +==(_________________________)==+            |"<<std::endl;
                                    f.close();
                                    return;
                                }
                                std::cout<<s<<std::endl;
                            }
                        }
                    }
                }
            }
        } //Read the text of a coorosponding '?' mark
        void teleport(coord c){
            ifstream f;
            f.open("misc/portal.txt");
            std::cout<<"Current map directory: "<<currMap.tfile<<std::endl;
            while(getline(f,in)){
                if (in == currMap.tfile){
                    while(getline(f,in)){
                        std::cout<<in<<std::endl;
                        if (in.find(getPointString())!=std::string::npos){
                            getline(f,in);
                            currMap = Map(in.substr(8,in.length()),1);
                            coll = Map(in.substr(8,in.length()),2);
                            getline(f,in);
                            setPoint(in);
                            currMap.printMap("Display.txt");
                            currMap.showOnDisp(point.getx(),point.gety(),screendimy*4,screendimy);
                            f.close();
                        }
                    }
                }    
            }
        }//Moves the character to a new position and map for a given position and tfile
        bool swordShop(){
            bool hasExit = false;
            bool bought = false;
            int page = 0;
            clearPage();
            do{
                clearPage();
                //Print out catalog
                for (int i = 0;i<5;i++){
                    if (((page*5)+(i-1))<swordLen){
                        weapon s = getWeaponInfo((page*5)+(i));
                        std::cout<<i+1<<" : "<<s.getName()<<std::endl;
                    }
                }
                std::cout<<""<<std::endl;
                std::cout<<"Input a number to inspect the weapon"<<std::endl;
                std::cout<<"        0 to exit"<<std::endl;
                std::cout<<"        6 to see more"<<std::endl;
                do{
                    std::cin>> in;
                }while(!(in[0]-48>=0&&in[0]-48<=6));
                weapon s;
                int c;
                bool b;
                switch(in[0]-48){//Buy options
                    case 1:
                    case 2:
                    case 3:                    
                    case 4:
                    case 5:
                        s = getWeaponInfo(page*5+in[0]-48-1);
                        clearPage();
                        s.printinfo();
                        std::cout<<"Purchase?"<<std::endl;
                        std::cout<<"1, to buy. 0 to not"<<std::endl;
                        c = choiceSelect(0,1);
                        if(c==1){
                            if (!(s.cost<=coin)){
                                std::cout<<"You are too poor to buy this"<<std::endl;
                                std::cin>>in;
                                break;
                            }
                            b = checkLineExist("Data/CurrData/weapon.txt",s.getName());
                            if (!b){                        
                                std::cout<<"You've purchased: "<<s.getName()<<std::endl;
                                coin = coin-s.cost;
                                updateValueFromFile("Data/CurrData/visStats.txt","Money",to_string(coin));
                                Winv[WinvLen] = s.getName();
                                WinvLen++;
                                bought = true;
                                Append("Data/CurrData/weapon.txt",s.getName());
                                std::cin>>in;
                                break;
                            }
                            std::cout<<"You already have this: "<<s.getName()<<std::endl;
                        }
                    break;
                    case 0://Exit
                        hasExit = true;
                    break;
                    case 6://Move another page up
                        page = (page+1)%(swordLen/5);
                    break;
                }
            } while(!hasExit);
            return bought;
        } //Opens sword shop 
        bool foodShop(){
            bool hasExit = false;
            bool bought = false;
            int page = 0;
            clearPage();
            do{
                clearPage();
                std::cout<<page<<"/"<<foodLen/5+1<<std::endl;
                //Print out catalog
                for (int i = 0;i<5;i++){
                    if (((page*5)+(i-1))<foodLen){
                        food s = getFoodInfo((page*5)+(i));
                        std::cout<<i+1<<" : "<<s.name<<std::endl;
                        std::cout<<"||||"<<s.Heal<<std::endl;
                    }
                }
                std::cout<<""<<std::endl;
                std::cout<<"Food costs as much as it heals"<<std::endl;
                std::cout<<"Input a number to purchase food"<<std::endl;
                std::cout<<"        0 to exit"<<std::endl;
                std::cout<<"        6 to see more"<<std::endl;
                do{
                    std::cin>> in;
                }while(!(in[0]-48>=0&&in[0]-48<=6));
                food s;
                int c;
                bool b;
                switch(in[0]-48){
                    case 1:
                    case 2:
                    case 3:                    
                    case 4:
                    case 5:
                        s = getFoodInfo(page*5+in[0]-48-1);
                        clearPage();
                        std::cout<<"Purchase "<<s.name<<"?"<<std::endl;
                        std::cout<<"1, to buy. 0 to not"<<std::endl;
                        c = choiceSelect(0,1);
                        if(c==1){
                            if (!(s.Heal<=coin)){
                                std::cout<<"You are too poor to buy this"<<std::endl;
                                std::cin>>in;
                                break;
                            }
                            b = checkLineExist("Data/CurrData/weapon.txt",s.name);
                            if (!b){                        
                                std::cout<<"You've purchased: "<<s.name<<std::endl;
                                coin = coin-s.Heal;
                                updateValueFromFile("Data/CurrData/visStats.txt","Money",to_string(coin));
                                Finv[WinvLen] = s.name;
                                FinvLen++;
                                bought = true;
                                Append("Data/CurrData/food.txt",s.name+"-"+to_string(s.Heal));
                                std::cin>>in;
                                break;
                            }
                            std::cout<<"You already have this: "<<s.name<<std::endl;
                        }
                    break;
                    case 0://Exit
                        hasExit = true;
                    break;
                    case 6://Move another page up
                        page = (page+1)%((foodLen/5)+1);
                        std::cout<<"Moving to page: "<<page<<std::endl;
                    break;
                }
            } while(!hasExit);
            return bought;        
        }//Opens food shop
        void openShop(){//Open the shop
            bool finished = false;
            do{
                std::cout<<"Welcome to my shop"<<std::endl;
                std::cout<<"1. Weapons"<<std::endl;
                std::cout<<"2. Food"<<std::endl;
                std::cout<<"3. Improve defense"<<std::endl;
                std::cout<<"4. Improve Health"<<std::endl;
                std::cout<<"5. Improve Speed"<<std::endl;
                std::cout<<"You have "<<coin<<" coins"<<std::endl;
                int c = choiceSelect(0,5);
                clearPage();
                int cost;
                int stattab[3] = {defence,maxHealth,speed};
                std::string statname[3] = {"Defence","Max Health","Speed"};
                int a;
                switch(c){
                    case 1:
                        swordShop();
                    break;
                    case 2:
                        foodShop();                        
                    break;
                    //Stat upgrades
                    case 3://Def
                    case 4://MaxH
                    case 5://Spd
                        cost = ((defence+1)*10);
                        std::cout<<"It costs "<<cost<<" to upgrade "<<statname[c-3]<<std::endl;
                        std::cout<<stattab[c-3]<<"-->"<<stattab[c-3]+1<<std::endl;
                        std::cout<<"1. Upgrade"<<std::endl;
                        std::cout<<"2. Don't"<<std::endl;
                        a = choiceSelect(1,2);
                        if (a==1){
                            if(coin>=cost){
                                coin = coin-cost;
                                updateValueFromFile("Data/CurrData/visStats.txt","Money",to_string(coin));
                                switch(c){
                                    case 3:
                                        defence++;
                                        a = defence;
                                    break;
                                    case 4:
                                        maxHealth++;
                                        a = maxHealth;
                                    break;
                                    case 5:
                                        speed++;
                                        a = speed;
                                    break;
                                }
                                updateValueFromFile("Data/CurrData/visStats.txt",statname[c-3],to_string(a));
                                std::cout<<"Upgraded to "<<getValueFromFile("Data/CurrData/visStats.txt",statname[c-3])<<std::endl;
                            }
                            std::cout<<"You cannot purchase this upgrade"<<std::endl;
                            std::cin>>in;
                        }
                    break; 
                    case 0:
                    std::cout<<"Thanks for coming by!"<<std::endl;
                        finished = true;
                    break;                
                }
            }while(!finished);
        }
        void charSwitch(){
            char c = currMap.getCharOnCoord(point);
            std::string in;
            switch (c){//Reads note. On the tin isn't it?
                case '?':
                    readNote();
                break;
                case '['://Spawns
                case ']':
                    std::cout<<"Are you sure you want to set your spawn to here?"<<std::endl;
                    std::cout<<"1 for yes"<<std::endl;
                    std::cout<<"0 for no"<<std::endl;
                    std::cin>>in;
                    if(stoi(in)==1){
                        setSpawn(point.getx(),point.gety());
                        updateValueFromFile("Data/CurrData/visStats.txt","Curr.Map",currMap.tfile);
                        copyfilesfromfolder(fileaccess,"CurrData");
                        std::cout<<"You will spawn back here when you enter the tower next time"<<std::endl;
                        return;
                    }
                case '@'://Chest
                break;
                case 'S'://Shop Keeper
                    openShop();
                break;
                case '{':
                case '}':
                    teleport(point);
                break;
                case '='://Closed door
                break;
                default:
                    optionInput("0");
                    std::cout<<"You cannot interact with this"<<std::endl;
                break;
            }
        } //Switch case for the character
        void openSetting(){
            readTxt("Graphics/settingMenu.txt");
            std::string in;
            int i = choiceSelect(0,4);
            int n;
            switch(i){
                case 1:
                    std::cout<<"How large should the screen be?"<<std::endl;
                    std::cin>>n;
                    screendimy = n;
                break;
                case 4:
                    std::cout<<"Choose how your character should look like"<<std::endl;
                    std::cin>>in;
                    skin = in[0];
                    updateValueFromFile("Data/CurrData/visStats.txt","Armor",to_string(in[0]));
                default:
                break;
            }
        } //Opens the setting
        bool openFoodMenu(bool infight){
            bool ate = false;
            int x;
            do{
                std::cout<<"]===================["<<std::endl;            
                std::ifstream f;
                f.open("Data/CurrData/food.txt");
                std::string in;
                int i = 0;
                while(getline(f,in)){
                    i++;
                    std::cout<<i<<"."<<in<<std::endl;
                }
                f.close();
                std::cout<<"]===================["<<std::endl;            
                std::cout<<"There is "<<i<<" food"<<std::endl;                
                std::cout<<"You have  "<<health<<"/"<<maxHealth<<" health currently"<<std::endl;                

                std::cout<<"Enter a number to consume the food, Press 0 to exit"<<std::endl;
                do{
                    std::cin>>x;
                } while(!(x>=0&&x<=i));
                std::ifstream inf;
                inf.open("Data/CurrData/food.txt");
                //if (x>=0&&x<=i){
                if (x == 0){
                    inf.close();
                    return ate;
                }
                ate = true;
                //Search for the chosen line
                for (int i = 1;i<=x;i++){
                    getline(inf,in);
                }
                //Update health and cout status
                int di = in.find("-");
                health+= stoi(in.substr(di+1,in.length()-(di+1)));
                if (health>maxHealth){
                    health = maxHealth;
                }
                std::cout<< "You ate "<<in.substr(0,di)<<" and healed "<<in.substr(di+1,in.length()-(di+1))<<" health"<<std::endl;
                std::ofstream tempof;//Temporary file to re-write the files
                tempof.open("Temp.txt");
                std::ifstream infA;
                infA.open("Data/CurrData/food.txt");
                int count = 1;
                while (getline(infA,in)){
                    if (count == x){
                        count++;
                        continue;
                    }
                    tempof<<in<<std::endl;
                    count++;
                }
                infA.close();
                tempof.close();
                ifstream tempif;
                ofstream otfA;
                tempif.open("Temp.txt");
                otfA.open("Data/CurrData/food.txt");
                while (getline(tempif,in)){
                    otfA<<in<<std::endl;
                }
                if (infight){
                    x = 0; 
                }
            } while(x!=0);
        } //Deprecated.
        void wepInventory(){
            ifstream f;
            f.open("Data/CurrData/weapon.txt");
            int i = 0;
            while (getline(f,in)){
                i++;
                Winv[i-1] = in;
                std::cout<<i<<" : "<<in<<std::endl;
            }
            WinvLen = i;
            int d;
            do{
                std::cin>>i;   
            }while(!(i>=0&&i<=swordLen));
            weapon s;
            switch(i){
                case 0:
                break;
                default:
                    clearPage();
                    for (int j = 0;j<WinvLen;j++){
                        if(swordtable[j].getName() == Winv[i-1]){
                            s = swordtable[j];       
                            break;
                        }
                    }
                    s.printinfo();
                    std::cout<<"equip?"<<std::endl;
                    std::cout<<"1. Equip"<<std::endl;
                    std::cout<<"2. Don't"<<std::endl;
                    d = choiceSelect(1,2);
                    if(d==1){
                        wep = s.getName();
                        attk = s.damage;
                        attkrng = s.range;
                        critchance = s.critchance;
                        critdamage = s.critdamage;
                        updateValueFromFile("Data/CurrData/visStats.txt","Strength",to_string(s.damage));
                        std::cout<<s.getName()<<" equipped"<<std::endl;
                    }
                break;
            }
            
        }//Open Inventory for weapon
        bool optionInput(std::string input){
            int d = 0;
            weapon s;
            bool finished = false;
            char keytable[] = {'w','a','d','s'};
            switch(input[0]){
                case '1'://stats
                    readTxt("Data/CurrData/visStats.txt");
                    if (wep!=""){
                        for (int i = 0;i<swordLen;i++){
                            if(swordtable[i].getName()== wep){
                                s = swordtable[i];
                                break;
                            }
                        }
                        s.printinfo();
                    }
                break;
                case '3'://Inventory
                    std::cout<<"This feature is buggy due to insuffecient devtime"<<std::endl;
                    do{
                        readTxt("Graphics/inventoryMenu.txt");
                        d = choiceSelect(0,3);
                        switch(d){
                            case 1:
                                wepInventory();
                            break;
                            case 2:
                                openFoodMenu(false);
                            break;
                            case 0:
                            finished = true;
                            break;
                        }
                    }while(!finished);
                break;
                case '5'://Interact
                    charSwitch();
                break;
                case '7'://Help
                    readTxt("Graphics/helpMenu.txt");
                break;
                case '9'://Setting
                    openSetting();
                break;
                case '2'://Movement
                case 'w':
                case '4':
                case 'a':
                case '6':
                case 'd':
                case '8':
                case 's':
                case '0':
                
                movecharacter(input,disp);
                if (!getPoint().gettf()){
                    std::cout <<"Enter proper input"<<std::endl;
                }
                break;
                default:
                return false;
                break;
            }
            return true;
        }//Accounts for the user input while in the over world
        void reSpawn(std::string loc, std::string m){ 
            int d = loc.find(",");
            setPoint(stoi(loc.substr(d+1,loc.length()-(d+1))),stoi(loc.substr(0,d)));
            currMap = Map("Map/"+m+"",1);
            coll = Map("Map/"+m+"",2);
        } //Respawns the player once dead
        int loadEnemy(){
            ifstream f;
            f.open("misc/Enemy.txt");
            while(getline(f,in)){
                
            }
        }//Deprecated
        int loadSword(){
            ifstream f;
            f.open("misc/sword.txt");
            int b = 0;//Line count
            int i = 0;//Weapon count
            std::string statT[5];
            int statTint[5];
            while(getline(f,in)){
                b++;
                if (in[0] == ':'){
                    swordLen++;
                    weapon w;
                    w.setImageLoc(b+3);//Set image location
                    w.setName(in.substr(1,in.length()));//Set name
                    //Set stats
                    getline(f,in);
                    b++;
                    split(in,'-',statT,5);
                    for (int j = 0;j<5;j++){
                        statTint[j] = stoi(statT[j]); 
                    }
                    w.setIntStat(statTint);
                    //Set description
                    getline(f,in);
                    b++;
                    w.setDesc(in);
                    //Find end of ascci image
                    while(getline(f,in)){
                        b++;
                        //std::cout<<in[0]<<std::endl;
                        if (in[0] == ']'){
                            w.setImageEnd(b);
                            break;
                        }
                    }
                    //Debug if properly loaded
                    swordtable[i] = w;
                    swordtable[i].printinfo();
                    std::cout<<swordtable[i].getName()<<" loaded"<<std::endl;

                    i++;
                }
            }
            clearPage();
        }//Load all weapon assets
        int loadFood(){
            int d;
            ifstream f;
            f.open("misc/food.txt");
            int i = 0;
            while(getline(f,in)){
                foodLen++;
                d = in.find("-");
                food fd = food(in.substr(0,d),stoi(in.substr(d+1,in.length())));
                foodlist[i] = fd;
                std::cout<<fd.name<<" loaded"<<std::endl;
                i++;
            }
            std::cout<<foodLen<<"/22 food asset loaded"<<std::endl;
        }//Load all food assets
};
class chest{
    private:
    coord pos;
    int wsize;
    food f[10];
    int fsize;
    int coin;
    std::string key;
    int armor;
};//Deprecated class
class game{// Game object, keeps track of player data such as inventory and stats
    private:
        std::string in;
    public:
        //Add to inventory
        void addFoodtoInventory(std::string item, player p){
        }
        bool addWeapontoInventory(std::string item, player p){
            std::string in;
            bool found = false;
            std::ifstream f;
            f.open("Data/CurrData/weapon.txt");
            while (getline(f,in)){
                if (in == item){
                    std::cout<<"You already have this item"<<std::endl;
                    found = true;
                    f.close();
                    return false;
                }                
            }
            std::ofstream of;
            of.open("Data/CurrData/weapon.txt", std::ofstream::out | std::ofstream::app);
            if (!found){
                of<<item;
            }

        }
        void addKeytoInventory(std::string key, player p){
            
        }
        void updateStat(std::string val, std::string newval){};
        //Load Assets

};//Deprecated

//#endif