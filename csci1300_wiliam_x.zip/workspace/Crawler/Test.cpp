#include "enemy.cpp"
#include <string>
#include <iostream>
using namespace std;
int main(){
    std::cout<<removeSpaces(" wawfaf aw ")<<std::endl;
}
