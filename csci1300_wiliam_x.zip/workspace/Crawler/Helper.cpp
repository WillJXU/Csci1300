#include <string>
#include <fstream>
#include <iostream>
#include <cmath>
#include <stdlib.h>  
#include <ctime>
#include <chrono>
#include <thread>
using namespace std;
std::string removeSpaces(std::string str) 
{ 
    std::string retStr = "               ";
    int count = 0; 
    for (int i = 0; i< str.length(); i++){
        if (str[i] != ' ') {
            retStr[count] = str[i];  
            count++;
            cout<<retStr<<std::endl;
        }                       
    }
    return retStr.substr(9,str.length());
} 
void errorCout(std::string parameter, std::string func, std::string reason){
    std::cout << "Warning! THE PARAMETER "<<parameter<<" OF THE FUNCTION "<<func<<" IS NOT WORKING PROPERLY. BECAUSE OF "<< reason<<std::endl;
    return;
}//Leaves unique error
void printTxtImage(std::string file, int min, int max){
    std::ifstream f;
    f.open(file);
    if (!f.is_open()){
        errorCout("file","printTxtImage","Bad filename");
        return;
    }
    std::string s;
    for (int i = 1;i<=max;i++){
        getline(f,s);
        if (i>= min){
            std::cout<<s<<std::endl;
        }
    }
    f.close();    
}//Prints parts of a txt file
int split (string str, char c, string array[], int size){
    if (str.length() == 0) {
        return 0;
    }
    string word = "";
    int count = 0;
    str = str + c;
    for (int i = 0; i < str.length(); i++){
        if (str[i] == c){
            if (word.length() == 0)
                continue;
            array[count++] = word;
            word = "";
        } else {
            word = word + str[i];
        }
    }
    return count ;
}
void coutPoint(std::string a){
    if (false){
        std::cout<<a<<std::endl;
    }
}//Function to mark important break points
void readTxt(std::string file){
    std::ifstream f;
    f.open(file);
    if (!f.is_open()){
        errorCout("file","readTxt","Bad filename");
        return;
    }
    std::string s;
    while(getline(f,s)){
        std::cout<<s<<std::endl;
    }
    f.close();
}//Print entire txt file
void copyfilesfromfolder(std::string chosensfile,std::string sourcefile){ 
    std::string in;
    std::string filename[7]{"chest","door","inventory","visStats","food","weapon","portal"};
    for (int i = 0;i<7;i++){
        std::ifstream deff;
        std::ofstream outf;
        deff.open("Data/"+sourcefile+"/"+filename[i]+".txt");
        outf.open("Data/"+chosensfile+"/"+filename[i]+".txt");
        while(getline(deff,in)){
            outf<<in<<std::endl;
        }
    }
}//Used to transfer save files
void clearPage(){
    for (int i = 0;i<20;i++){
        std::cout<<""<<std::endl;
    }
}//Clean the console
void Append(std::string file,std::string s){
    ofstream f;
    std::string in;
    f.open(file,fstream::app);
    f<<s<<std::endl;
}
bool checkLineExist(std::string file,std::string s){
    ifstream f;
    std::string in;
    f.open(file);
    bool found = false;
    while(getline(f,in)){
        if(in == s){
            found = true;
        }
    }
    return found;
}
int choiceSelect(int min, int max){
    std::string in;
    do{
        std::cin>> in;
    }while(!(in[0]-48>=min&&in[0]-48<=max));
    return in[0]-48;
}//Function to allow player choice
std::string getValueFromFile(std::string file,std::string attri){
    ifstream f;
    string s;
    f.open(file);
    while(getline(f,s)){
        if(s.find(attri)!=std::string::npos){
            return s.substr(18,s.length()-18);
        }
    }
}//Get value from visStat
void updateValueFromFile(std::string file,std::string attri, std::string newval){
    ofstream temp;
    temp.open("Temp.txt");
    ifstream f;
    string s;
    f.open(file);
    //std::cout<<"Is this open?"<<f.is_open()<<std::endl;
    while(getline(f,s)){
        if(s.find(attri)!=std::string::npos){
            s = s.substr(0,18) + newval;
        }
        temp<<s<<std::endl;
    }
    f.close();
    temp.close();
    ifstream itemp;
    ofstream of;
    itemp.open("Temp.txt");
    of.open(file);
    while(getline(itemp,s)){
        of<<s<<std::endl;    
    }
    itemp.close();
    of.close();
}//Set value from visStat