#include <string>
#include <fstream>
#include <iostream>
#include <cmath>
#include <stdlib.h>  
#include <ctime>
#include <chrono>
#include <thread>
#include "gameComponent.cpp"
//#include "Helper.cpp"
#include <unistd.h>
#include <time.h> 

class enemy{
    public:
        //std::string gameSet[20] = {0,1,2};
        int gameSetLength=3;
    //Roshambo
        int ROstrat = 1;
        int rounds = 5;
    //21
        int TOStrat = 1;
        int TOval[3] = {10,0,0};
    //Dice
        int DIStrat = 0;
        int thresh = 3;
        int Winstate = 20;
    //Enemy attribute
        //int lvl = 0;
        std::string name = "Skeleton";
        int movesperturn = 1;
        int attk = 1;
        int attkrng = 3;
        int defence = 0;
        int currDef = 0;
        int harden = 1;
        int heal = 1;
        int health = 5;
        int maxHealth = 5;
        int imagestart =3;
        int imageend =18;
        int coin;
        std::string in;
        enemy(std::string a){//Boss constructor
            if (a=="Minotaur"){
        name = "Minotaur";
        movesperturn = 1;
        attk = 10;
        attkrng = 10;
        defence = 10;
        currDef = 10;
        harden = 1;
        heal = 1;
        health = 200;
        maxHealth = 200;
        imagestart =141;
        imageend =164;
        coin = 500; 
        std::cout << name << std::endl;
            }
        }
        enemy(int l){//Grunt constructor
            srand (time(NULL)); 
            int d = rand()%l+1;
            switch(d){
                case 1:
        name = "Skeleton";
        movesperturn = 1;
        attk = 1;
        attkrng = 3;
        defence = 0;
        currDef = 0;
        harden = 1;
        heal = 1;
        health = 5;
        maxHealth = 5;
        imagestart = 3;
        imageend = 18; 
        coin = 10;
                break;
                case 2:
        name = "The headless horseman's head";
        movesperturn = 1;
        attk = 2;
        attkrng = 2;
        defence = 0;
        currDef = 0;
        harden = 1;
        heal = 1;
        health = 8;
        maxHealth = 8;
        imagestart =22;
        imageend =32;
        coin = 20;
                break;
                case 3:
        name = "The Haunted Tickle me Elmo doll";
        movesperturn = 1;
        attk = 5;
        attkrng = 2;
        defence = 0;
        currDef = 0;
        harden = 1;
        heal = 1;
        health = 4;
        maxHealth = 4;
        imagestart =38;
        imageend =46;
        coin = 30;
                break;
                case 4:
        name = "A bat Vampire";
        movesperturn = 1;
        attk = 4;
        attkrng = 2;
        defence = 10;
        currDef = 0;
        harden = 1;
        heal = 1;
        health = 8;
        maxHealth = 8;
        imagestart =50;
        imageend =56;
        coin = 30;
                break;
                case 5:
        name = "Golum";
        movesperturn = 1;
        attk = 8;
        attkrng = 0;
        defence = 30;
        currDef = 0;
        harden = 1;
        heal = 1;
        health = 6;
        maxHealth = 6;
        imagestart =60;
        imageend =69;
        coin = 50;
                break;
                case 6:
        name = "Fenrir";
        movesperturn = 1;
        attk = 3;
        attkrng = 5;
        defence = 40;
        currDef = 0;
        harden = 1;
        heal = 1;
        health = 12;
        maxHealth = 12;
        imagestart =74;
        imageend =88;
        coin = 50;
                break;
                case 7:
        name = "Shitty Dragon";
        movesperturn = 1;
        attk = 6;
        attkrng = 5;
        defence = 10;
        currDef = 0;
        harden = 1;
        heal = 1;
        health = 10;
        maxHealth = 6;
        imagestart = 92;
        imageend =102;
        coin = 80;
                break;
                case 8:
        name = "Friendly demon";
        movesperturn = 1;
        attk = 3;
        attkrng = 5;
        defence = 0;
        currDef = 0;
        harden = 1;
        heal = 1;
        health = 12;
        maxHealth = 12;
        imagestart = 107;
        imageend =121;
        coin = 100;
                break;
                case 9:
        name = "Poltergeist";
        movesperturn = 1;
        attk = 5;
        attkrng = 6;
        defence = 30;
        currDef = 0;
        harden = 1;
        heal = 1;
        health = 20;
        maxHealth = 20;
        imagestart = 125;
        imageend =138;
        coin = 100;
                break;
            }
        }
//games
        int roshambo(int r){//Rock Paper scissor
        clearPage();
            srand (time(NULL));
            int you = 0;//Score for player
            int enemy = 0;//Score for enemy
            std::string rpsname[3]={"Rock","Paper","Scissors"};
            int rpswin[3]={3,1,2};
            for (int w = 0;w<r;w++){//Go through all the rounds
                do{//cout menu
                    clearPage();
                    std::cout<<"[ Round: "<<w<<"/"<<r<<" ]"<<std::endl;
                    readTxt("Graphics/game/rpsmenu.txt");
                    std::cout<<"        Scores:       "<<std::endl;
                    std::cout<<"  You: "<<you<<" Vs. Enemy: "<<enemy<<std::endl;
                    std::cin>>in;
                } while((in[0]-48)<1||(in[0]-48)>3);
                int rps = rand()%3+1;
                std::cout<<rpsname[in[0]-49]<<" vs "<<rpsname[rps-1]<<std::endl;
                //std::cout<<in[0]<<","<<rps<<std::endl;
                if (rpswin[in[0]-49] == rps){//If Player wins
                    std::cout<<"You won this round!"<<std::endl;
                    you++;
                }
                else if(rpswin[rps-1] == in[0]-48){//If enemt wins
                    std::cout<<"You lost this round!"<<std::endl;
                    enemy++;
                }
                else{//If tied
                    std::cout<<"Tied!"<<std::endl;
                }
                std::cout<<"Press any key to continue"<<std::endl;
                std::cin>>in;
            }
            if (you>enemy){
                readTxt("Graphics/victory.txt");
                std::cout<<"Press any key to continue"<<std::endl;
                std::cin>>in;
                return 1;
            }
            else{
                readTxt("Graphics/defeat.txt");         
                std::cout<<"Press any key to continue"<<std::endl;
                std::cin>>in;
            }
            return 0;
        } //RPS
        int twentyone(int strat,int valA,int valB,int valC){
            clearPage();
            srand (time(NULL));
            //set up the cards and hand
            int sets[4][13];
            int cards[13]={1,2,3,4,5,6,7,8,9,10,10,10,10};
            for (int i = 0;i<4;i++){
                for (int j = 0;j<13;j++){
                    sets[i][j] = cards[j];
                }    
            }
            bool end = false;
            int hand[2][21];
            for (int p = 0;p<2;p++){
                for (int i = 0;i<21;i++){
                    hand[p][i] = 0;
                }    
            }
            int cround = 0;
            int r;
            bool hitfold[2] = {true,true};
            std::string who[2] = {"Enemy","You"};
            int sum[2] = {0,0};//Sum of the points
            while(!end){//Game loop
                if (!hitfold[0]&&!hitfold[1]){//Win condition, checks if both stood
                    usleep(3000000);
                    int win;
                    if(sum[1]>21){
                        readTxt("Graphics/defeat.txt");//Player folded
                        win = 0;
                    }
                    else{ 
                        if(sum[0]>21){
                            readTxt("Graphics/victory.txt");//Enemy Folded
                            win = 1;
                        }
                        else{//Both enemy and player didn't fold
                            if(sum[1]>sum[0]){
                                readTxt("Graphics/victory.txt");//Player has larger sum
                                win = 1;
                            }
                            else{
                                readTxt("Graphics/defeat.txt");
                                win = 0;
                            }
                        }
                    }
                    std::cout<<"You: "<<sum[1]<<" Vs "<<"Enemy: "<<sum[0]<<std::endl;
                    std::cout<<""<<std::endl;
                    std::cout<<"Press any key to continue"<<std::endl;
                    std::cin>>in;
                    return win;//Return who had the largest su,
                }
                for (int i = 0;i<2;i++){//Player loop
                    if (hitfold[i]){//If player is still not holding
                        usleep(700000);  
                        if (i==1){
                            do{//Player move cout menu
                                readTxt("Graphics/game/twentyone.txt");
                                std::cout<<"These are your 'cards'"<<std::endl;
                                int sum = 0;
                                for (int p = 0;p<cround;p++){
                                    std::cout<<"["<<hand[1][p]<<"]";
                                    sum += hand[1][p];
                                }
                                std::cout<<""<<std::endl;
                                std::cout<<"Adds up to "<< sum<<std::endl;
                                std::cin>>in;
                                r = (in[0]-48);
                            }while(!(r>0&&r<=2));
                        }
                        else{//Enemy move, contains enemy strategy
                            switch(strat){
                                case 2://strat 2 Always fold once threshold passed
                                    if (sum[0]>valA){
                                        r = 2;
                                    }
                                    else{
                                        r = 1; 
                                    }
                                break;
                                case 1:
                                default://Strat 1. if sum is higher than threshold, randomly choose
                                    if (sum[0]>valA){
                                        r = rand()%2;
                                    }
                                    else{
                                        r = 1; 
                                    }
                                break;
                            }
                        }
                        if (r == 1){//When they hit
                            std::cout<<who[i]<<" hit!"<<std::endl;
                            int c = 0;
                            int rset;
                            int rcard;
                            do{
                                rset = rand()%4;
                                rcard = rand()%13;
                                c = sets[rset][rcard];
                                sets[rset][rcard] = 0;
                            }while(c==0);
                            hand[i][cround] = c;
                            int s=0;
                            for (int j = 0;j<=cround;j++){
                                s += hand[i][j];
                            }
                            sum[i] = s;
                            //Hand states
                            if (sum[i]<21){//If didn't fold
                                hitfold[i] = true;
                            }
                            else if (sum[i]==21){//If sum is 21
                                hitfold[i] = false; 
                                break;
                            }
                            else{
                                hitfold[i] = false; 
                                for (int i = 0;i<cround;i++){
                                    std::cout<<"["<<hand[1][i]<<"]";
                                }
                                std::cout<<""<<std::endl;
                                std::cout<<who[i]<<" folded."<<std::endl; 
                                break;
                            }
                        }
                        else{
                            std::cout<<who[i]<<" hold"<<std::endl;
                            hitfold[i] = false;

                        }
                    }
                }
                cround++;
            }
        }//BlackJAck
        int diceGame(int winstate,int stratagy){//Dirty Dce
            clearPage();
            srand (time(NULL));
            int rollresult[6] = {0,1,-1,2,5,3};
            int game[2] = {0,0};
            int turn[2] = {0,0};
            int r; //roll input
            int winner;
            do{//Loop the game until win state met
                for (int i=0;i<2;i++){//Loop between each player
                    if ((game[1] >= winstate)||(game[0] >= winstate)){//Check for winners
                        winner = (game[1]>=game[0]);
                        break;
                    }
                    int roll = 0; 
                    do{//Turn loop
                        std::cout<<""<<std::endl;
                        //User input
                        if(i == 1){
                            do{ // Game Menu User input
                                clearPage();    
                                clearPage();
                                std::cout<<"Your turn"<<std::endl;
                                readTxt("Graphics/game/dicegamemenu.txt");
                                std::cout<<"|>First to "<<winstate<<" wins"<<std::endl;
                                std::cout<<"|>Your Current roll: "<<turn[1]<<std::endl;
                                std::cout<<"|>Your Total: "<<game[1]<<std::endl;
                                std::cout<<"|>Enemy roll: "<<turn[0]<<std::endl;
                                std::cout<<"|>Enemy Total: "<<game[0]<<std::endl;
                                std::cout<<"|>This was last rolled: "<<roll<<std::endl;
                                std::cin>>in;
                                r = (in[0]-48);
                            } while(!(r<=2&&r>0));
                        }
                        //Enemy input
                        else{
                            //std::cout<<"Enemy turn"<<std::endl;
                            switch(stratagy){
                                case 1:
                                    if (turn[0]<=thresh){
                                        r = 1;
                                    }
                                    else{
                                        r = 2;
                                    }
                                break;
                                case 0:
                                default:
                                    r = rand()%2+1;
                                break;
                            }
                        }
                        if (r==2){//If no roll
                            game[i]+=turn[i];
                            turn[i]=0;
                            break;
                        }
                        roll = rand()%6+1;//Random Roll
                        std::cout<<"Rolled "<<roll<<std::endl;
                        usleep(700000);
                        if (roll%2==0){//If roll is even
                            turn[i]+=rollresult[roll-1];
                            if(game[i]>=winstate){//If anyone cracks through the winstate end loop
                                break;
                            }
                        }
                        else{//If roll is odd, end turn
                            turn[i] = rollresult[roll-1];
                            game[i]+=turn[i];
                            turn[i] = 0;
                            break;
                        }
                    }while(true);
                }
            } while(game[0]<winstate&&game[1]<winstate);
            if(game[0]>=winstate){
                readTxt("Graphics/defeat.txt");
                winner = 0;
            }
            else{
                readTxt("Graphics/victory.txt");
                winner = 1;
            }
            std::cin>> in;
            return winner;
        }
        /*void gameRandselect(int games[],int tabLen){
            for (int i = 0;i<tabLen;i++){
                switch(game[i]){
                    case 1:
                        roshambo();
                    break;
                    case 2:
                        twentyone(1);
                    break;
                    case 3:
                        diceGame(20,1);
                    break;
                }
            }
        }*/
        int switchFight(int i){
            int a;
            switch(i){
                case 1:
                a = twentyone(1,TOval[0],TOval[1],TOval[2]);
                break;
                case 2:
                a = diceGame(Winstate,1);
                break;
                case 0:
                a = roshambo(rounds);
                default:
                break;
            }
            return a;
        }
//actions 
        bool healthupdate(int damage){
            health = health-(damage-damage*(currDef/100));
            std::cout<<"Their health is now "<<health<<std::endl;
            currDef = defence;
            return (health<=0);
        }//These were never used
        void recover(){
            health+=heal;
        }//These were never used
        void fight(player p){//Start fight
            srand (time(NULL));
            ifstream fin;
            ifstream stats;
            ofstream out;
            fin.open("Graphics/game/FightMenu.txt");
            out.open("Graphics/game/FightMenuWData.txt");
            int count = 0;
            std::string icon[4] = {"@","&","%","???"};
            std::string attri[3] = {"Strength","Defence","Health"};
            while(getline(fin,in)){//Initialize fight menu
                if(in.find(icon[count])!=std::string::npos){
                    std::string s = p.getStats(attri[count]);
                    //std:cout<<"S is "<<s<<endl;
                    for (int i=0;i<s.length();i++){
                        in[25+i] = s[i];
                    }
                    count++;
                }
                out<<in<<std::endl;
            }
            fin.close();
            out.close();
            clearPage();
            readTxt("Graphics/game/danger.txt");
            std::cin>>in;
            printTxtImage("misc/Enemy.txt",imagestart,imageend);
            std::cout<<"You have come across a "<<name<<"!"<<std::endl;
            std::cin>>in;
            bool alive = true;
            bool loss = false;
            do{
                if (health <= 0){
                    alive = false;
                    break;
                }
                int a = rand()%gameSetLength;
                if (switchFight(a)==1){
                    std::cin>>in;
                    clearPage();
                    bool ok = false; //Move is completed when ok is true
                    do{//Menu loop, only done when action is confirmed
                        do{//Cout the fight options and status
                            clearPage();
                            printTxtImage("misc/Enemy.txt",imagestart,imageend);
                            readTxt("Graphics/game/FightMenuWData.txt");
                            std::cout<<"[Health]"<<std::endl;
                            std::cout<<"     | You |"<<std::endl;
                            std::cout<<"[";
                                for(int i = 1;i<p.maxHealth;i++){
                                    if (i<=p.health){
                                        std::cout<<"|";
                                        continue;
                                    }
                                    std::cout<<"_";
                                }
                            std::cout<<"]"<<std::endl;
                            std::cout<<"     |Enemy|"<<std::endl;
                            std::cout<<"[";
                                for(int i = 1;i<maxHealth;i++){
                                    if (i<=health){
                                        std::cout<<"|";
                                        continue;
                                    }
                                    std::cout<<" ";
                                }
                            std::cout<<"]"<<std::endl;
                            std::cout<<"You won this turn what to do?"<<std::endl;
                            std::cin>>in;
                        }while(in[0]-48>4||in[0]-48<=0);//Input range
                        int crit;
                        int dmg;
                        switch(in[0]-48){
                            case 1://Damage
                                crit = (((rand()%100)+1)<=p.critchance);
                                dmg = (p.attk+(rand()%(p.attkrng+1)-1))*(!crit)+(p.critdamage*crit);
                                std::cout<<"You dealt "<<dmg<<" damage"<<std::endl;
                                healthupdate(dmg);
                                std::cout<<"You've attacked the enemy"<<std::endl;
                                if (health <=0){
                                    alive = false;
                                    loss = false;
                                }
                                ok = true;
                            break;
                            case 2://Defence
                                if(p.currDef<p.defence){
                                    p.currDef = p.defence;
                                }
                                p.currDef+=p.harden;
                                std::cout<<"You've upped your defence"<<std::endl;
                                ok = true;
                            break;
                            case 3://Heal
                                if(p.openFoodMenu(true)){
                                    ok = true;
                                }
                            break;
                            case 4:
                                do{
                                    clearPage();
                                    std::cout<<"You can only flee if you have less than 5 health"<<std::endl;
                                    std::cout<<"Otherwise you will penalized 20 coins"<<std::endl;
                                    std::cout<<"You currently have "<<p.coin<<" coins"<<std::endl;
                                    std::cout<<"1. Flee, accept any penalty"<<std::endl;
                                    std::cout<<"2. Keep on fighting"<<std::endl;
                                    std::cin>>in;
                                }while(!(in[0]-48>0&&in[0]-48<=2));
                                if (in[0]-48==1){
                                    if (!(p.health>5&&p.coin>=20)){
                                        std::cout<<"You cannot satisfy the penalties"<<std::endl;
                                        std::cin>>in;
                                        continue;
                                    }
                                    p.coin-=20;
                                    return;
                                }
                            break;
                        }
                    }while(!ok);
                }//If player wins
                else{//If player loses, will only attack. I've run out of time to handle the rest
                    int d = attk+rand()%(attkrng+1)-1;
                    std::cout<<"Enemy deals "<<d<<" damage"<<std::endl;
                    p.healthupdate(d);
                    if (p.health <= 0){
                        alive = false;
                        loss = true;
                    }
                }
                clearPage();
                //Debug, show the current health
                std::cout<<"[Health]"<<std::endl;
                std::cout<<"     | You |"<<std::endl;
                std::cout<<"[";
                    for(int i = 1;i<p.maxHealth;i++){
                        if (i<=p.health){
                            std::cout<<"|";
                            continue;
                        }
                        std::cout<<" ";
                    }
                std::cout<<"]"<<std::endl;
                std::cout<<"     |Enemy|"<<std::endl;
                std::cout<<"[";
                    for(int i = 1;i<maxHealth;i++){
                        if (i<=health){
                            std::cout<<"|";
                            continue;
                        }
                        std::cout<<" ";
                    }
                std::cout<<"]"<<std::endl;
            }while(alive);
            if (loss){//When you lose.
                readTxt("Graphics/youdied.txt");
                std::cout<<"Press any key to continue"<<std::endl;
                std::string loc = getValueFromFile("Data/"+p.getFileAccess()+"visStats.txt","Spawn Loc.");
                std::string map = getValueFromFile("Data/"+p.getFileAccess()+"visStats.txt","Spawn Loc.");
                p.reSpawn(loc,map);
                std::string h = getValueFromFile("Data/"+p.getFileAccess()+"visStats.txt","Health");
                p.health = stoi(h);
                copyfilesfromfolder("CurrData",p.getFileAccess());
                std::cin>>in;
                return;
            }
            else{
                clearPage();
                readTxt("Graphics/victory.txt");
                std::cout<<"YOU WON!"<<std::endl;
                std::cout<<"You've earned:"<<std::endl;
                std::cout<<"Coins: "<<coin<<std::endl;
                p.coin = p.coin+coin;
                p.totcoin = p.totcoin + coin;
                std::cout<<"Press any key to continue"<<std::endl;
                updateValueFromFile("Data/CurrData/visStats.txt","Money",to_string(p.coin));
                updateValueFromFile("Data/CurrData/visStats.txt","Ex",to_string(p.totcoin));
                if (name =="Minotaur"){
                    p.Boss[0] = true;
                }
                std::cin>>in;
                p.optionInput("0");
                return;                
            }
        }
        
};

