#include "Helper.cpp"
#include <string>
class weapon{
    private:
    std::string name;
    int id;
    int imageLoc;
    int imageEnd;
    public:
    //Stats
    int damage;
    int range;
    int critdamage;
    int critchance;
    int cost;
    std::string desc;
    std::string getName(){
        return name;
    }
    void printinfo(){//Print info of weapon
        std::cout<<"Name: "<<name<<std::endl;
        std::cout<<"    Damage      : "<<damage<<std::endl;
        std::cout<<"    Range       : "<<range<<std::endl;
        std::cout<<"    Crit. Damage: "<<critdamage<<std::endl;
        std::cout<<"    Crit Chance : "<<critchance<<std::endl;
        std::cout<<"    [Description]"<<std::endl;
        std::cout<<"||["<<desc<<"]||"<<std::endl;
        printTxtImage("misc/sword.txt",imageLoc,imageEnd);
        std::cout<<"Cost: "<<cost<<std::endl;
    }
    void setName(std::string s){
        name = s;
    }
    void setDesc(std::string s){
        desc = s;
    }
    void setImageLoc(int s){
        imageLoc = s;
    }   
    void setImageEnd(int s){
        imageEnd = s;
    }       
    void setIntStat(int tab[]){
        damage = tab[0];
        range = tab[1];
        critdamage = tab[2];
        critchance = tab[3];
        cost = tab[4];
    }
};
class food{
    private:
    public:
    std::string name;
    int Heal;
    
    food(){
        name = "";
        Heal = 0 ; 
    }
    food(std::string n,int h){
        name = n;
        Heal = h;
    }
};
