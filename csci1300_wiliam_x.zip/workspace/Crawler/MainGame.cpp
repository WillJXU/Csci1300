#include <iostream>
#include <fstream>
//#include "Helper.cpp"
#include "enemy.cpp"
#include <string>
using namespace std;
void intro(){
    ifstream f;
    std:string in;
    f.open("Graphics/lore.txt");
    while(getline(f,in)){
        if (in == "["){
            while(getline(f,in)){
                if(in=="]"){
                    break;
                }
                std::cout<<in<<std::endl;
            }
        }
        std::cout<<"Enter anything to continue"<<std::endl;
        std::cin>>in;
    }
}
int main(){
    //Loading assets
    clearPage();
    player p;
    //Player set up
/*    p.currMap = Map("Map/enter",1);//Render
    p.coll = Map("Map/enter",2);//Collision
    p.setSpawn(5,8);//Spawn
    p.setPoint(5,8);//Position
 */
    std::string in;
    clearPage();
    readTxt("Graphics/Title.txt");
    std::cout<<"Press any key to progress"<<std::endl;
    std::cin>>in;
    clearPage();
    //menu loop
    bool opened = true;
    while (opened){//Save file options
        std::string svfile[3] = {"FileA","FileB","FileC"};
        std::string chosensfile;
        ifstream lamp;
        lamp.open("Graphics/savefile.txt");
        for (int i=0;i<11;i++){
            getline(lamp,in);
            std::cout<<in<<std::endl;
        }
        bool ok = false;
        do{//Expect proper input
            std::cout<<""<<std::endl;
            std::cin>>in;
            std::cout<<""<<std::endl;
            if((in[0]-'0'>=1)&&(in[0]-'0'<=3)){
                chosensfile = svfile[(in[0]-49)];
                ok = true;
            }
            else{
                std::cout<<"Enter a valid input, dummy    "<<std::endl;
            }
        } while (!ok);
        for (int i=0;i<6;i++){//Print the image
            getline(lamp,in);
            std::cout<<in<<std::endl;
        }
        ok = false;
        do{
            std::cout<<""<<std::endl;
            std::cin>>in;
            std::cout<<""<<std::endl;
            int choice = in[0]-'0';
            ifstream cfile;
            ofstream ocfile;
            cfile.open("Data/"+chosensfile+"/notnew.txt");
            switch(choice){
                case 1:
                    copyfilesfromfolder("CurrData",chosensfile);
                    if (!cfile.is_open()){//When starting a new save
                        copyfilesfromfolder(chosensfile,"Default");
                        intro();
                        ocfile.open("Data/"+chosensfile+"/notnew.txt");
                    }
                    opened = false;
                    p = player("Data/"+chosensfile+"/visStats.txt");
                    p.loadSword();   
                    p.loadFood();
                    p.currMap.printMap("Display.txt");//Outputting to display
                    ok = true;
                    p.changeFileAccess(chosensfile);
                break;                
                case 2:
                    do{
                        std::cout<<"Are you sure you want to delete this save?"<<std::endl;
                        std::cout<<"1. Yes delete this file"<<std::endl;
                        std::cout<<"2. No do not"<<std::endl;
                        std::cin>>in;
                    }while(!(in[0]-48<=2&&in[0]-48>0));
                    if(in[0]-48 == 1){
                        copyfilesfromfolder(chosensfile,"Default");
                        std::remove(("Data/"+chosensfile+"/notnew.txt").c_str());
                        std::cout<<"Save file has been Defiled"<<std::endl;
                    }
                break;
                case 3:
                    lamp.close();
                    ok = true;
                break;
                default:
                    std::cout<<"You troglodyte I'd thought you'd figure out how to do this by now"<<std::endl;
                break;
            }
        } while (!ok);
    }
    clearPage();
    p.optionInput("0");
    while (true){
        std::cout<<"Give input. For help press 7"<<std::endl;
        std::cin>>in;
        clearPage();
        if (!p.optionInput(in)){
            std::cout<<"Put a proper input"<<std::endl;
        }
        else{//Ending dialog
            if ((p.getPoint().getx()==63) &&(p.getPoint().gety() ==4)){
                std::cout<<"Condgratulations, you win"<<std::endl;
std::cin>>in;
                std::cout<<"Unfortinatly duee to running out of time I've had to cut the game short"<<std::endl;
std::cin>>in;
                std::cout<<"So this is the ending. Unless you give me an assignment extention. "<<std::endl;
std::cin>>in;
                std::cout<<"So that's it, bye bye. "<<std::endl;
std::cin>>in;
                std::cout<<"Youve finally found your wallet"<<std::endl;
std::cin>>in;
                std::cout<<"Now get out"<<std::endl;
std::cin>>in;
            }
            if ((p.getPoint().getx()==63) &&(p.getPoint().gety() ==6)){//Boss
                enemy d("Minotaur");
                std::cout<<d.name<<std::endl;
                d.fight(p);
            }
            else if ((rand()%15 == 0)&&(p.currMap.tfile != "Map/enter")){
                int lvl = (p.totcoin/100)+1;
                enemy e = enemy(lvl);
                e.fight(p);
            }
        }
    }
}