#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
using namespace std;
void printIneligiblePlayers(std::string name[],float age[], int size){
    for (int i = 0;i<size;i++){
        if ( 4 <=age[i] && 6>= age[i])
        std::cout<<name[i]<<" "<<age[i]<<std::endl;
    }
}

int main(){
std::string name[4] = {"Joe", "Jack", "Amy", "Bob"};
float age[4] = {3.4, 5.6, 6.0, 4.2};
printIneligiblePlayers(name,age,4);
}