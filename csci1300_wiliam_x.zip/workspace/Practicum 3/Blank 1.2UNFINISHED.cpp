#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
using namespace std;
int calcPay(string file){
    ifstream f;
    f.open(file);
    if(!f.is_open()){
        return -1;        
    }
    string s="";
    int num = 0;
    float total = 0;
    while(getline(f,s)){
        if(s != ""){
            string arr[3];
            Split(s,',',arr,3);
            float a = stof(arr[1])*stof(arr[2]);
            cout<<arr[0]<<": "<<a<<endl;
            num++;
            total += a;
        }
    }
    cout<<"Total: "<<total<<endl; 
    return num;
}

int main(){

}