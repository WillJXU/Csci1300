#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
using namespace std;

int sumOfPositiveOdd(string file, int arr[], int size){
    ofstream f;
    f.open(file);
    if(!f.is_open()){
        return -1;        
    }
    int tot = 0;
    for(int i = 0;i<size;i++){
        tot = tot + arr[i]*(arr[i]%2)*(arr[i]>=0);
    }   
    f << tot;
    return 1;
}

int main(){
    int numarray[4] = {1,2,2,3};
    sumOfPositiveOdd("a.txt",numarray,4);
}