#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
using namespace std;
int minElement(int num[][2], int size){
    int min = num[0][0];
    for (int i=0;i<size;i++){
        for (int j=0;j<2;j++){
            min = ((min<num[i][j])*min)+((min>=num[i][j])*num[i][j]);    
        }
    }
    return min;
}

int main(){
int inpt_arr[2][2] = {{1,2},{3,4}};
cout << minElement(inpt_arr,2) << endl;
}